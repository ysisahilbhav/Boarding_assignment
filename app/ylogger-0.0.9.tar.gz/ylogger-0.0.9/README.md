# **What is it?**

Yardi Logger

## **installation**

`pip install .`

Note: Use `-v` is for showing logs during installation 