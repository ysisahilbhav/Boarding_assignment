import logging
from typing import Union

from ylogger.DBLoggingHandler.DBConfig import MySqlConfig, SqlConfig
from ylogger.JsonLoggingHandler import JsonLoggingHandler
from ylogger.LoggerConfig import LoggerConfig


def set_log_config():
    logging.basicConfig(
        format="%(asctime)s %(levelname)-8s %(message)s",
        level=logging.DEBUG,
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=[],
    )


def get_my_logger(
    name: str,
    logger_config: LoggerConfig = LoggerConfig(),
    db_config: Union[SqlConfig, MySqlConfig] = SqlConfig(),
) -> logging.Logger:
    set_log_config()
    logger = logging.getLogger(name)

    logger.handlers.clear()
    yardiLIH = JsonLoggingHandler(
        name, logger_config.save_to_file, logger_config.file_path
    )
    logger.addHandler(yardiLIH)

    if logger_config.save_to_sql:
        if type(db_config) is SqlConfig:
            from ylogger.DBLoggingHandler.SQLLoggingHandler import SQLHandler

            sqlh = SQLHandler(name, db_config)
            logger.addHandler(sqlh)
        else:
            from ylogger.DBLoggingHandler.MySQLLoggingHandler import MySQLHandler

            mysqlh = MySQLHandler(name, db_config)
            logger.addHandler(mysqlh)

    logger.propagate = False

    return logger
