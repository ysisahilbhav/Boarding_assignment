from typing import Optional

from pydantic_settings import BaseSettings, SettingsConfigDict


class LoggerConfig(BaseSettings):
    save_to_file: Optional[bool] = False
    file_path: Optional[str] = "./log.log"

    save_to_sql: Optional[bool] = False
    model_config = SettingsConfigDict(env_prefix="logger_")
