import copy
import json
import logging
import time
from datetime import datetime
from logging import LogRecord
from pprint import pformat


class JsonLoggingHandler(logging.StreamHandler):
    def __init__(self, app_name, save_to_file=False, file_path="./log.log"):
        super().__init__()
        self.save_to_file = save_to_file
        self.file_path = file_path
        self.json_template = {
            "yardi": {
                "log": {
                    "timestamp": "%(created)s",
                    "level": "%(levelname)s",
                    "message": "%(msg)s",
                    "exception": "%(exc_text)s",
                    "source": app_name,
                    "origin": {
                        "function": "%(funcName)s",
                        "file": {"name": "%(filename)s", "line": 0},
                    },
                }
            }
        }

    def handle(self, record: LogRecord) -> bool:
        super().handle(record)
        if self.save_to_file:
            with open(self.file_path, "a+") as f:
                f.write(pformat(vars(record)) + "\n")

        return True

    def get_event_dict(self, _id, duration):
        event_dict = {"duration": duration, "name": "Timed Event", "id": _id}
        return event_dict

    def formatRecordTime(self, timestamp):
        return (
            datetime.fromtimestamp(timestamp).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3]
            + "Z"
        )

    def emit(self, record):
        """
        Format template json, print to stdout
        @param record:
        @return:
        """
        if record.exc_info:
            record.exc_text = logging._defaultFormatter.formatException(record.exc_info)
        else:
            record.exc_text = ""

        # get correct time format
        record_dict = record.__dict__.copy()

        record_dict["msg"] = self.format(record)
        record_dict["msg"] = json.dumps(record_dict["msg"]).strip('"')

        record_dict["created"] = self.formatRecordTime(record_dict["created"])
        record_dict["exc_text"] = json.dumps(record_dict["exc_text"]).strip('"')

        json_msg = copy.deepcopy(self.json_template)
        json_msg["yardi"]["log"]["origin"]["file"]["line"] = record_dict["lineno"]

        # check if we need to create event object
        if isinstance(record_dict["msg"], str) and "@@@" in record_dict["msg"]:
            _id = record_dict["msg"].split("@@@")[0].strip()
            duration = record_dict["msg"].split("@@@")[1].strip()
            try:
                duration = float(duration)
            except Exception:
                duration = 0
            record_dict["msg"] = None

            event_dict = self.get_event_dict(_id, duration)
            json_msg["yardi"]["event"] = event_dict

        json_msg = json.dumps(json_msg) % record_dict

        self.stream.write(json_msg)
        self.stream.write(self.terminator)
        self.flush()
