from typing import Optional

from pydantic import SecretStr
from pydantic_settings import BaseSettings, SettingsConfigDict


class SqlConfig(BaseSettings):
    database: Optional[str] = ""
    host: Optional[str] = ""
    port: Optional[int] = 0
    user: Optional[str] = ""
    password: SecretStr = ""
    model_config = SettingsConfigDict(env_prefix="logger_sql_")


class MySqlConfig(BaseSettings):
    database: Optional[str] = ""
    host: Optional[str] = ""
    port: Optional[int] = 0
    user: Optional[str] = ""
    password: SecretStr = ""
    model_config = SettingsConfigDict(env_prefix="logger_mysql_")
