import logging
import time
import six
import pyodbc

from ylogger.DBLoggingHandler.DBConfig import SqlConfig


class SQLHandler(logging.Handler):
    def __init__(self, prefix: str, config: SqlConfig = SqlConfig()):
        super().__init__()

        self.prefix = prefix

        # SQL configurations
        self.database_name = config.database
        self.sql_host = config.host
        self.sql_port = config.port
        self.sql_user = config.user
        self.sql_pswd = config.password.get_secret_value()

        self.initial_sql = """
            IF OBJECT_ID(N'dbo.{}logs', N'U') IS NULL
                CREATE TABLE [dbo].[{}logs](
                  [Created] DATETIME DEFAULT CURRENT_TIMESTAMP,
                  [Name] TEXT,
                  [LogLevel] [int],
                  [LogLevelName] TEXT,
                  [Message] TEXT,
                  [Args] TEXT,
                  [Module] TEXT,
                  [FuncName] TEXT,
                  [LineNo] [int],
                  [Exception] TEXT,
                  [Process] [int],
                  [Thread] TEXT,
                  [ThreadName] TEXT
                );
        """.format(
            self.prefix, self.prefix
        )

        self.insertion_sql = """
        INSERT INTO {0}logs([Name], [LogLevel], [LogLevelName], [Message], [Args], [Module], [FuncName], [LineNo],
            [Exception], [Process], [Thread], [ThreadName])
        VALUES ('%(name)s', %(levelno)d, '%(levelname)s', '%(msg)s', '%(args)s', '%(module)s', '%(funcName)s',
            %(lineno)d, '%(exc_text)s', %(process)d, '%(thread)s', '%(threadName)s');
        """.format(
            self.prefix
        )

        # Check if 'log' table in db already exists
        result = self.checkTablePresence()
        # If not exists, then create the table
        if not result:
            try:
                con = self.get_connection()
            except Exception as e:
                raise Exception(e)
            else:
                cur = con.cursor()
                try:
                    cur.execute(self.initial_sql)
                except Exception as e:
                    con.rollback()
                    con.close()
                    raise Exception(e)
                else:
                    con.commit()
                finally:
                    con.close()

    def get_connection(self):
        con = pyodbc.connect(
            """DRIVER={{ODBC Driver 17 for SQL Server}};SERVER={},{};DATABASE={};UID={};PWD={}""".format(
                self.sql_host,
                self.sql_port,
                self.database_name,
                self.sql_user,
                self.sql_pswd,
            )
        )
        return con

    def checkTablePresence(self):
        try:
            con = self.get_connection()
        except Exception as e:
            raise Exception(e)
        else:
            # Check if 'log' table in db already exists
            cur = con.cursor()
            stmt = "SELECT OBJECT_ID(N'dbo.{}logs', N'U');".format(self.prefix)

            result = None
            try:
                cur.execute(stmt)
                result = cur.fetchone()
            except Exception:
                pass
            con.close()

        if not result[0]:
            return 0
        else:
            return 1

    def formatDBTime(self, record):
        """
        Time formatter
        @param record:
        @return: nothing
        """
        record.dbtime = time.strftime(
            "%Y-%m-%d %H:%M:%S", time.localtime(record.created)
        )

    def emit(self, record):
        """
        Connect to DB, execute SQL Request, disconnect from DB
        @param record:
        @return:
        """
        # Use default formatting:
        msg = self.format(record)
        # Set the database time up:
        self.formatDBTime(record)
        if record.exc_info:
            record.exc_text = logging._defaultFormatter.formatException(record.exc_info)
        else:
            record.exc_text = ""

        record.__dict__["msg"] = msg
        record.__dict__["args"] = tuple()

        # Replace single quotes in messages
        if isinstance(record.__dict__["message"], str):
            record.__dict__["message"] = record.__dict__["message"].replace("'", "''")

        if isinstance(record.__dict__["exc_text"], str):
            record.__dict__["exc_text"] = record.__dict__["exc_text"].replace("'", "''")

        if isinstance(record.__dict__["msg"], str):
            record.__dict__["msg"] = record.__dict__["msg"].replace("'", "''")

        if isinstance(record.__dict__["msg"], AttributeError):
            record.__dict__["msg"] = record.__dict__["msg"].args[0].replace("'", "''")

        # Insert log record:
        try:
            con = self.get_connection()
        except Exception as e:
            print("The Exception during db.connect")
            raise Exception(e)

        # escape the message to allow for SQL special chars
        if isinstance(record.msg, six.string_types):  # check is a string
            record.msg = record.msg

        sql = self.insertion_sql % record.__dict__

        cur = con.cursor()
        try:
            cur.execute(sql)
        except Exception as e:
            print("Error inserting logs in db: {}".format(e))
        else:
            try:
                con.commit()
            except Exception:
                pass
        finally:
            con.close()
