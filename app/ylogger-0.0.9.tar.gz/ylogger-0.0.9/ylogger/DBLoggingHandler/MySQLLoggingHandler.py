import logging
import time
import six
import mysql.connector

from ylogger.DBLoggingHandler.DBConfig import MySqlConfig


class MySQLHandler(logging.Handler):
    def __init__(self, prefix, config: MySqlConfig = MySqlConfig()):
        super().__init__()

        self.prefix = prefix

        # Database configuration
        db_config = {
            "host": config.host,
            "port": int(config.port),
            "user": config.user,
            "password": config.password.get_secret_value(),
            "database": config.database,
        }

        self.mysql = mysql.connector.connect(**db_config)
        self.initial_sql = """CREATE TABLE IF NOT EXISTS {0}log(
        Created TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        Name text,
        LogLevel int,
        LogLevelName text,
        Message text,
        Args text,
        Module text,
        FuncName text,
        LineNo int,
        Exception text,
        Process int,
        Thread text,
        ThreadName text
        )""".format(
            self.prefix
        )

        self.insertion_sql = """INSERT INTO {0}log(
        Name,
        LogLevel,
        LogLevelName,
        Message,
        Args,
        Module,
        FuncName,
        LineNo,
        Exception,
        Process,
        Thread,
        ThreadName
        )
        VALUES (
        '%(name)s',
        %(levelno)d,
        '%(levelname)s',
        '%(msg)s',
        '%(args)s',
        '%(module)s',
        '%(funcName)s',
        %(lineno)d,
        '%(exc_text)s',
        %(process)d,
        '%(thread)s',
        '%(threadName)s'
        );
        """.format(
            self.prefix
        )

        # Check if 'log' table in db already exists
        result = self.checkTablePresence()

        # If not exists, then create the table
        if not result:
            try:
                conn = self.get_connection()
            except Exception as e:
                raise Exception(e)
            else:
                with conn.cursor() as cur:
                    try:
                        cur.execute(self.initial_sql)
                    except Exception as e:
                        conn.rollback()
                        cur.close()
                        conn.close()
                        raise Exception(e)
                    else:
                        conn.commit()
                    finally:
                        cur.close()
                        conn.close()

    def get_connection(self):
        return self.mysql

    def checkTablePresence(self):
        with self.mysql.cursor() as cur:
            stmt = "SHOW TABLES LIKE '{0}log';".format(self.prefix)
            try:
                cur.execute(stmt)
                result = cur.fetchone()
            except Exception:
                pass

        if not result:
            return 0
        else:
            return 1

    def formatDBTime(self, record):
        record.dbtime = time.strftime(
            "%Y-%m-%d %H:%M:%S", time.localtime(record.created)
        )

    def emit(self, record):
        # Use default formatting:
        msg = self.format(record)
        # Set the database time up:
        self.formatDBTime(record)
        if record.exc_info:
            record.exc_text = logging._defaultFormatter.formatException(record.exc_info)
        else:
            record.exc_text = ""

        record.__dict__["msg"] = msg
        record.__dict__["args"] = tuple()

        # Replace single quotes in messages
        if isinstance(record.__dict__["message"], str):
            record.__dict__["message"] = record.__dict__["message"].replace("'", "''")

        if isinstance(record.__dict__["exc_text"], str):
            record.__dict__["exc_text"] = record.__dict__["exc_text"].replace("'", "''")

        if isinstance(record.__dict__["msg"], str):
            record.__dict__["msg"] = record.__dict__["msg"].replace("'", "''")

        if isinstance(record.__dict__["msg"], AttributeError):
            record.__dict__["msg"] = record.__dict__["msg"].args[0].replace("'", "''")

        # Insert log record:
        try:
            conn = self.get_connection()
        except Exception as e:
            print("The Exception during db.connect")
            raise Exception(e)

        # escape the message to allow for SQL special chars
        if isinstance(record.msg, six.string_types):  # check is a string
            record.msg = conn.escape_string(record.msg)

        sql = self.insertion_sql % record.__dict__
        with conn.cursor() as cur:
            try:
                cur.execute(sql)
            except Exception as e:
                print("Error inserting logs in db: {}".format(e))
            else:
                try:
                    conn.commit()
                except Exception:
                    pass
            finally:
                cur.close()
