import importlib.metadata

from .global_logger import get_my_logger
from .LoggerConfig import LoggerConfig

__all__ = ["get_my_logger", "LoggerConfig"]

__version__ = importlib.metadata.version(__package__)
