import logging

from testfixtures import log_capture

from ylogger.DBLoggingHandler.MySQLLoggingHandler import MySQLHandler, MySqlConfig


@log_capture()
def test_json_string_formatting(capture):
    logger = logging.getLogger()

    logger.addHandler(MySQLHandler("", MySqlConfig()))

    logger.info("Hello %s", "there")

    capture.check(("root", "INFO", "Hello there"))

    # TODO: test in local db
