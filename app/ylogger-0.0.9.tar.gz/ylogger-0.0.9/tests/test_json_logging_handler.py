import logging

from testfixtures import log_capture

from ylogger.JsonLoggingHandler import JsonLoggingHandler


@log_capture()
def test_json_string_formatting(capture):
    logger = logging.getLogger()

    logger.addHandler(JsonLoggingHandler("tests"))

    logger.info("Hello %s", "there")

    capture.check(("root", "INFO", "Hello there"))
