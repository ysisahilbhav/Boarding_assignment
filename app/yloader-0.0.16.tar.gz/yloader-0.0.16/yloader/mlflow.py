import logging
import os

from ysecret.SecretManager import SecretManager

logger = logging.getLogger(__name__)


class MlflowBase:
    def __init__(self, artifact_root="s3://mlflow/"):
        super().__init__()
        id = 138530
        secret_manger = SecretManager(use_password=True)
        secrets = secret_manger.get_secret_with_id(id)
        os.environ["AWS_ACCESS_KEY_ID"] = secrets["AWS_ACCESS_KEY_ID"]
        os.environ["AWS_SECRET_ACCESS_KEY"] = secrets["AWS_SECRET_ACCESS_KEY"]
        endpoint_url = secrets["AWS  ARN"]
        endpoint_url = "https://" + endpoint_url
        os.environ["MLFLOW_S3_ENDPOINT_URL"] = endpoint_url
        os.environ["MLFLOW_DEFAULT_ARTIFACT_ROOT"] = artifact_root
        os.environ["MLFLOW_ARTIFACTS_DESTINATION"] = artifact_root
