import asyncio


def auto_start_as_task(func):
    def wrapper(*args, **kwargs):
        task = asyncio.create_task(func(*args, **kwargs))
        return task

    return wrapper
