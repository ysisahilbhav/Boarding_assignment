from contextlib import asynccontextmanager
from logging import Logger
from typing import Any, AsyncGenerator, List, Optional, Tuple, Union

import cx_Oracle
import pandas as pd
from typing_extensions import override
from yloader.databases.clients.async_oracle import create_pool
from yloader.databases.clients.base import BaseClient
from yloader.databases.clients.type_stubs import Connection
from yloader.databases.connections import OracleSQLCredentials
from yloader.databases.utils.async_utils import auto_start_as_task


class OracleSQLClient(BaseClient):
    credentials: OracleSQLCredentials

    def __init__(self, credentials: OracleSQLCredentials, logger: Logger) -> None:
        self.logger = logger
        self.credentials = credentials

    @override
    def create_connection(self):
        connection = cx_Oracle.connect(
            self.credentials.username,
            self.credentials.password.get_secret_value(),
            cx_Oracle.makedsn(
                self.credentials.host,
                self.credentials.port,
                self.credentials.service_name,
            ),
        )
        connection.autocommit = True
        return connection

    @override
    async def acreate_connection(self):
        raise NotImplementedError

    @override
    @asynccontextmanager
    async def aget_connection(
        self,
        retries: int = 0,
    ) -> AsyncGenerator[Connection, None]:
        pool = await create_pool(
            host=self.credentials.host,
            port=self.credentials.port,
            user=self.credentials.username,
            password=self.credentials.password.get_secret_value(),
            service_name=self.credentials.service_name,
            min=1,
            max=1,
        )
        async with pool.acquire() as connection:
            yield connection

    @override
    def execute(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> None:
        # The oracle cursor requires query variables to be passed in as an array
        # (or dictionary) instead of args (or kwargs). Passing in args below does
        # that conversion
        super().execute(query, args, retries=retries, timeout=timeout)

    @override
    @auto_start_as_task
    async def aexecute(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> None:
        # The oracle cursor requires query variables to be passed in as an array
        # (or dictionary) instead of args (or kwargs). Passing in args below does
        # that conversion
        await super().aexecute(query, args, retries=retries, timeout=timeout)

    @override
    def fetch_one(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> Tuple[Any, ...]:
        # The oracle cursor requires query variables to be passed in as an array
        # (or dictionary) instead of args (or kwargs). Passing in args below does
        # that conversion
        return super().fetch_one(query, args, retries=retries, timeout=timeout)

    @override
    @auto_start_as_task
    async def afetch_one(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> Tuple[Any, ...]:
        # The oracle cursor requires query variables to be passed in as an array
        # (or dictionary) instead of args (or kwargs). Passing in args below does
        # that conversion
        return await super().afetch_one(
            query,
            args,
            retries=retries,
            timeout=timeout,
        )

    @override
    def fetch_all(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> List[Tuple[Any, ...]]:
        # The oracle cursor requires query variables to be passed in as an array
        # (or dictionary) instead of args (or kwargs). Passing in args below does
        # that conversion
        return super().fetch_all(
            query,
            args,
            retries=retries,
            timeout=timeout,
        )

    @override
    @auto_start_as_task
    async def afetch_all(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> List[Tuple[Any, ...]]:
        # The oracle cursor requires query variables to be passed in as an array
        # (or dictionary) instead of args (or kwargs). Passing in args below does
        # that conversion
        return await super().afetch_all(
            query,
            args,
            retries=retries,
            timeout=timeout,
        )

    @override
    def fetch_dataframe(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
        column_names: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        # The oracle cursor requires query variables to be passed in as an array
        # (or dictionary) instead of args (or kwargs). Passing in args below does
        # that conversion
        return super().fetch_dataframe(
            query,
            args,
            retries=retries,
            timeout=timeout,
            column_names=column_names,
        )

    @override
    @auto_start_as_task
    async def afetch_dataframe(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
        column_names: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        # The oracle cursor requires query variables to be passed in as an array
        # (or dictionary) instead of args (or kwargs). Passing in args below does
        # that conversion
        return await super().afetch_dataframe(
            query,
            args,
            retries=retries,
            timeout=timeout,
            column_names=column_names,
        )
