from abc import ABC, abstractmethod
from contextlib import asynccontextmanager, contextmanager
from logging import Logger
from typing import Any, AsyncGenerator, Generator, List, Optional, Tuple, TypeVar, Union

import pandas as pd
from typing_extensions import ParamSpec
from yloader.databases.clients.type_stubs import Connection, Cursor
from yloader.databases.clients.utils.async_execute_query_retry_timeout import (
    AExecuteQueryRetryTimeout,
)
from yloader.databases.clients.utils.execute_query_retry_timeout import (
    ExecuteQueryRetryTimeout,
)
from yloader.databases.connections import BaseCredentials
from yloader.databases.utils.async_utils import auto_start_as_task

T = TypeVar("T")
P = ParamSpec("P")


class BaseClient(ABC):
    logger: Logger
    credentials: BaseCredentials

    @abstractmethod
    def create_connection(self) -> Connection: ...

    #
    # TODO: change this to creating pools first
    #
    @abstractmethod
    async def acreate_connection(self) -> Connection: ...

    @contextmanager
    def get_connection(self, retries: int = 0) -> Generator[Connection, None, None]:
        connection = self.create_connection()

        # TODO:
        # If failure try to refresh secrets server creds?
        # if self.creds.is_from_secrets_sever:
        #     self.creds.refresh_from_secret_server()

        try:
            yield connection
        finally:
            connection.close()

    @asynccontextmanager
    async def aget_connection(
        self,
        retries: int = 0,
    ) -> AsyncGenerator[Connection, None]:
        # TODO:
        # If failure try to refresh secrets server creds?
        # if self.creds.is_from_secrets_sever:
        #     self.creds.refresh_from_secret_server()

        async with await self.acreate_connection() as connection:
            yield connection

    @contextmanager
    def get_cursor(self, connection: Connection) -> Generator[Cursor, None, None]:
        cursor = connection.cursor()

        try:
            yield cursor
        finally:
            cursor.close()

    @asynccontextmanager
    async def aget_cursor(
        self,
        connection: Connection,
    ) -> AsyncGenerator[Cursor, None]:
        cursor = await connection.cursor()

        try:
            yield cursor
        finally:
            await cursor.close()

    def execute(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> None:
        with self.get_connection() as connection:
            with self.get_cursor(connection) as cursor:
                timeout_decorator = ExecuteQueryRetryTimeout(
                    self.logger,
                    retries,
                    timeout,
                )
                timeout_decorator(cursor.execute, query, *args)
                connection.commit()

    @auto_start_as_task
    async def aexecute(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> None:
        async with self.aget_connection() as connection:
            async with self.aget_cursor(connection) as cursor:
                timeout_decorator = AExecuteQueryRetryTimeout(
                    self.logger,
                    retries,
                    timeout,
                )
                await timeout_decorator(cursor.execute, query, *args)
                await connection.commit()

    def fetch_one(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> Tuple[Any, ...]:
        with self.get_connection() as connection:
            with self.get_cursor(connection) as cursor:
                timeout_decorator = ExecuteQueryRetryTimeout(
                    self.logger,
                    retries,
                    timeout,
                )
                timeout_decorator(cursor.execute, query, *args)
                data = cursor.fetchone()
                cursor.commit()
                return data

    @auto_start_as_task
    async def afetch_one(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> Tuple[Any, ...]:
        async with self.aget_connection() as connection:
            async with self.aget_cursor(connection) as cursor:
                timeout_decorator = AExecuteQueryRetryTimeout(
                    self.logger,
                    retries,
                    timeout,
                )
                await timeout_decorator(cursor.execute, query, *args)
                data = await cursor.fetchone()
                await cursor.commit()
                return data

    def fetch_all(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> List[Tuple[Any, ...]]:
        with self.get_connection() as connection:
            with self.get_cursor(connection) as cursor:
                timeout_decorator = ExecuteQueryRetryTimeout(
                    self.logger,
                    retries,
                    timeout,
                )
                timeout_decorator(cursor.execute, query, *args)
                data = cursor.fetchall()
                cursor.commit()
                return data

    @auto_start_as_task
    async def afetch_all(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
    ) -> List[Tuple[Any, ...]]:
        async with self.aget_connection() as connection:
            async with self.aget_cursor(connection) as cursor:
                timeout_decorator = AExecuteQueryRetryTimeout(
                    self.logger,
                    retries,
                    timeout,
                )
                await timeout_decorator(cursor.execute, query, *args)
                data = await cursor.fetchall()
                await cursor.commit()
                return data

    def fetch_dataframe(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
        column_names: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        with self.get_connection() as connection:
            with self.get_cursor(connection) as cursor:
                timeout_decorator = ExecuteQueryRetryTimeout(
                    self.logger,
                    retries,
                    timeout,
                )
                timeout_decorator(cursor.execute, query, *args)

                result = cursor.fetchall()
                cursor.commit()
                return result_to_dataframe(result, cursor, column_names)

    @auto_start_as_task
    async def afetch_dataframe(
        self,
        query: str,
        *args: Union[str, float],
        retries: int = 0,
        timeout: Union[float, None] = None,
        column_names: Optional[List[str]] = None,
    ) -> pd.DataFrame:
        async with self.aget_connection() as connection:
            async with self.aget_cursor(connection) as cursor:
                timeout_decorator = AExecuteQueryRetryTimeout(
                    self.logger,
                    retries,
                    timeout,
                )
                await timeout_decorator(cursor.execute, query, *args)

                result = await cursor.fetchall()
                await cursor.commit()
                return result_to_dataframe(result, cursor, column_names)

    def __str__(self) -> str:
        return f'credentials={self.credentials}, logger="{self.logger.name}"'

    def __repr__(self) -> str:
        return f"{self.__class__.__name__}(credentials={self.credentials}, logger={self.logger})"


def result_to_dataframe(
    result: List[Tuple[Any]],
    cursor,
    column_names: Optional[List[str]] = None,
):
    column_names = (
        column_names
        if column_names is not None
        else [column[0].lower() for column in cursor.description]
    )
    return pd.DataFrame.from_records(result, columns=column_names)
