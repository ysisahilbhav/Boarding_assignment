import threading
import time
from logging import Logger
from typing import Callable, TypeVar, Union

from typing_extensions import ParamSpec

from .errors import FunctionTimeoutError

T = TypeVar("T")
P = ParamSpec("P")

DEFAULT_RETURN = "_no_return"


class ThreadWithReturnValue(threading.Thread):
    def __init__(self, group=None, target=None, name=None, args=(), kwargs={}):
        threading.Thread.__init__(
            self, group=group, target=target, name=name, args=args, kwargs=kwargs
        )
        self._return = DEFAULT_RETURN

    def run(self):
        if self._target is not None:
            self._return = self._target(*self._args, **self._kwargs)

    @property
    def result(self):
        return self._return


class ExecuteQueryRetryTimeout:
    def __init__(
        self,
        logger: Logger,
        retries: int = 0,
        timeout_seconds: Union[float, None] = None,
        raise_last_error: bool = True,
        fail_on_first_timeout: bool = True,
    ):
        self.logger = logger
        self.retries = retries
        self.timeout_seconds = timeout_seconds
        self._raise_last_error = raise_last_error
        self._fail_on_first_timeout = fail_on_first_timeout

    @property
    def raise_last_error(self) -> bool:
        return self._raise_last_error

    @property
    def fail_on_first_timeout(self) -> bool:
        return self._fail_on_first_timeout

    def __call__(
        self, func: Callable[P, T], query: str, *args: P.args, **kwargs: P.kwargs
    ) -> Union[T, None]:
        error: Union[Exception, None] = None

        for call_count in range(self.retries + 1):
            last_loop = call_count == self.retries

            if call_count > 0:
                self.logger.info("Retrying query (retry=%d) %s", call_count, query)

            try:
                thread = ThreadWithReturnValue(
                    target=func, args=(query, *args), kwargs=kwargs
                )
                thread.daemon = True

                thread.start()
                thread.join(self.timeout_seconds)

                if isinstance(thread.result, str) and thread.result == DEFAULT_RETURN:
                    if thread.is_alive():
                        raise FunctionTimeoutError

                return thread.result
            except FunctionTimeoutError as e:
                error = e
                self.logger.warning(
                    "Query timed-out after %f seconds, %s",
                    self.timeout_seconds,
                    query,
                )

                if self.fail_on_first_timeout:
                    raise error
            except Exception as e:
                self.logger.warning(
                    "Exception executing query %s",
                    query,
                    exc_info=True,
                    stack_info=True,
                )
                error = e

            if not last_loop:
                time.sleep(1)

        if self.raise_last_error and error is not None:
            raise error

        return None
