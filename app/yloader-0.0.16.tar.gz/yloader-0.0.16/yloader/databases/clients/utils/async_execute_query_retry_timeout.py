import asyncio
from logging import Logger
from typing import Callable, TypeVar, Union

from typing_extensions import ParamSpec

from .errors import FunctionTimeoutError

T = TypeVar("T")
P = ParamSpec("P")


class AExecuteQueryRetryTimeout:
    def __init__(
        self,
        logger: Logger,
        retries: int = 0,
        timeout_seconds: Union[float, None] = None,
        raise_last_error: bool = True,
        fail_on_first_timeout: bool = True,
    ):
        self.logger = logger
        self.retries = retries
        self.timeout_seconds = timeout_seconds
        self._raise_last_error = raise_last_error
        self._fail_on_first_timeout = fail_on_first_timeout

    @property
    def raise_last_error(self) -> bool:
        return self._raise_last_error

    @property
    def fail_on_first_timeout(self) -> bool:
        return self._fail_on_first_timeout

    async def __call__(
        self,
        func: Callable[P, T],
        query,
        *args: P.args,
        **kwargs: P.kwargs,
    ) -> Union[T, None]:
        error: Union[Exception, None] = None

        for call_count in range(self.retries + 1):
            last_loop = call_count == self.retries

            if call_count > 0:
                self.logger.info("Retrying query (retry=%d) %s", call_count, query)

            try:
                return await asyncio.wait_for(
                    # wrap in task to prevent coroutine never awaited warning:
                    asyncio.create_task(func(query, *args, **kwargs)),
                    timeout=self.timeout_seconds,
                )
            except asyncio.TimeoutError as e:
                error = FunctionTimeoutError(e)
                self.logger.warning(
                    "Query timed-out after %f seconds, %s",
                    self.timeout_seconds,
                    query,
                )

                if self.fail_on_first_timeout:
                    raise error
            except Exception as e:
                self.logger.warning(
                    "Exception executing query %s",
                    query,
                    exc_info=True,
                    stack_info=True,
                )
                error = e

            if not last_loop:
                await asyncio.sleep(1)

        if not self.raise_last_error and error is not None:
            raise error

        return None
