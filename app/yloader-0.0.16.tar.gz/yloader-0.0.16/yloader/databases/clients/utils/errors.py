class FunctionTimeoutError(Exception):
    pass
