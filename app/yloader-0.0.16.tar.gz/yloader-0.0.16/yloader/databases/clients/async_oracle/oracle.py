# We're using the cx_Oracle_asnyc package: https://github.com/GoodManWEN/cx_Oracle_async
# and unfortunately, it's cursor object does not save the description, so we cannot
# get the column names when creating a dataframe
#
# This file is a wrapper around the cx_Oracle_async package in order to get the
# cursor.description values but ideally there is a better way to do this...

from __future__ import annotations

import asyncio
from asyncio import ProactorEventLoop

import cx_Oracle
from cx_Oracle_async.connections import AsyncConnectionWrapper
from cx_Oracle_async.cursors import AsyncCursorWrapper
from cx_Oracle_async.pools import AsyncPoolWrapper, AsyncPoolWrapper_context


class AsyncOraclePool(AsyncPoolWrapper):
    def _acquire(self):
        wrapper = AsyncOracleConnection(
            self._pool.acquire(),
            self._loop,
            self._thread_pool,
            self._pool,
            self,
        )
        self._occupied.add(wrapper)
        return wrapper


class AsyncOracleConnection(AsyncConnectionWrapper):
    def _cursor(self):
        return AsyncOracleCursor(self._conn.cursor(), self._loop, self._thread_pool)


class AsyncOracleCursor(AsyncCursorWrapper):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self._description = []

    async def execute(self, sql, *args, **kwargs):
        result = await super().execute(sql, *args, **kwargs)
        self._description = self._cursor.description
        return result

    async def executemany(self, sql, *args, **kwargs):
        result = await super().executemany(sql, *args, **kwargs)
        self._description = self._cursor.description
        return result

    async def fetchone(self):
        result = await super().fetchone()
        self._description = self._cursor.description
        return result

    async def fetchall(self):
        result = await super().fetchall()
        self._description = self._cursor.description
        return result

    @property
    def description(self):
        return self._description

    async def close(self): ...


async def _create_pool(
    host: str = None,
    port: str = None,
    service_name: str = None,
    sid: str = None,
    loop: ProactorEventLoop = None,
    dsn: str = None,
    **kwargs,
):
    if loop is None:
        loop = asyncio.get_running_loop()
    if dsn is None:
        if service_name is not None:
            dsn = cx_Oracle.makedsn(
                host=host, port=port, sid=sid, service_name=service_name
            )
        else:
            dsn = cx_Oracle.makedsn(host=host, port=port, sid=sid)
    pool = cx_Oracle.SessionPool(dsn=dsn, **kwargs)
    pool = AsyncOraclePool(pool)
    return pool


def create_pool(
    user: str = None,
    password: str = None,
    dsn: str = None,
    min: int = 2,
    max: int = 4,
    increment=1,
    connectiontype=cx_Oracle.Connection,
    threaded=True,
    getmode=cx_Oracle.SPOOL_ATTRVAL_WAIT,
    events=False,
    homogeneous=True,
    externalauth=False,
    encoding="UTF-8",
    edition=None,
    timeout=0,
    waitTimeout=0,
    maxLifetimeSession=0,
    sessionCallback=None,
    maxSessionsPerShard=0,
    host: str = None,
    port: str = None,
    service_name: str = None,
    sid: str = None,
    loop: ProactorEventLoop = None,
):
    coro = _create_pool(
        user=user,
        password=password,
        dsn=dsn,
        min=min,
        max=max,
        increment=increment,
        connectiontype=connectiontype,
        threaded=threaded,
        getmode=getmode,
        events=events,
        homogeneous=homogeneous,
        externalauth=externalauth,
        encoding=encoding,
        edition=edition,
        timeout=timeout,
        waitTimeout=waitTimeout,
        maxLifetimeSession=maxLifetimeSession,
        sessionCallback=sessionCallback,
        maxSessionsPerShard=maxSessionsPerShard,
        host=host,
        port=port,
        service_name=service_name,
        sid=sid,
        loop=loop,
    )
    return AsyncPoolWrapper_context(coro)
