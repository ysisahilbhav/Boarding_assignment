from logging import Logger

import aioodbc
import pyodbc
from typing_extensions import override
from yloader.databases.clients.base import BaseClient
from yloader.databases.clients.type_stubs import Connection
from yloader.databases.connections import MsSQLCredentials


class MsSQLClient(BaseClient):
    credentials: MsSQLCredentials

    def __init__(self, credentials: MsSQLCredentials, logger: Logger) -> None:
        self.logger = logger
        self.credentials = credentials

    @override
    def create_connection(self) -> Connection:
        return pyodbc.connect(self.credentials.dsn)

    @override
    async def acreate_connection(self) -> Connection:
        return await aioodbc.connect(dsn=self.credentials.dsn)
