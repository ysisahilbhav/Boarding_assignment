from pydantic import SecretStr

from .base import BaseCredentials


class MsSQLCredentials(BaseCredentials):
    username: str
    password: SecretStr
    host: str
    port: int
    db_name: str

    @property
    def dsn(self) -> str:
        return (
            "DRIVER={ODBC Driver 17 for SQL Server};"
            f"SERVER={self.host},{self.port};"
            f"DATABASE={self.db_name};"
            f"UID={self.username};"
            f"PWD={self.password.get_secret_value()}"
        )

    @property
    def pyodbc_connection_string(self) -> str:
        creds = f"{self.username}:{self.password.get_secret_value()}"
        conn = f"{creds}@{self.host}:{self.port}/{self.db_name}"
        return f"mssql+pyodbc://{conn}?driver=ODBC+Driver+17+for+SQL+Server"
