from pydantic import SecretStr

from .base import BaseCredentials


class OracleSQLCredentials(BaseCredentials):
    username: str
    password: SecretStr
    host: str
    port: int
    service_name: str
