from typing import Union

try:
    from typing import Self
except Exception:
    from typing_extensions import Self

from pydantic import BaseModel
from ysecret.SecretManager import SecretManager


class SecretServerIdNotSet(Exception):
    pass


class BaseCredentials(BaseModel):
    _secret_server_id: Union[int, None] = None

    @classmethod
    def from_secret_server(cls, secret_id: int, use_password: bool = True) -> Self:
        sm = SecretManager(use_password=use_password)
        secret = sm.get_secret_with_id(secret_id)
        result = cls(**secret)
        result._secret_server_id = secret_id
        return result

    def refresh_from_secret_server(self) -> None:
        if not self.is_from_secret_server:
            raise SecretServerIdNotSet

        new_creds = self.from_secret_server(self._secret_server_id)
        for field_name, new_value in new_creds.items():
            setattr(self, field_name, new_value)

    @property
    def is_from_secret_server(self) -> bool:
        return self._secret_server_id is not None
