import logging
import os
import cv2
import numpy as np
import smbclient
from PIL import Image
from smbclient.path import isdir

from yloader.schemas import SmbConfig
from ysecret.SecretManager import SecretManager

logger = logging.getLogger(__name__)


class SmbManager:
    def __init__(self, smbConfig: SmbConfig):
        self.smb_host = smbConfig.smb_host
        self.share_name = smbConfig.share_name
        self.smb_password = smbConfig.smb_password
        if smbConfig.domain_name:
            self.smb_username = f"{smbConfig.domain_name}\\{smbConfig.smb_username}"
        else:
            self.smb_username = smbConfig.smb_username
        self.directory_path = smbConfig.directory_path

    @staticmethod
    def get_samba_ycrm(id_=None) -> "SmbManager":
        if id_ is None:
            id_ = 187212
        secret_manger = SecretManager(use_password=True)
        secrets = secret_manger.get_secret_with_id(id_)
        smb_config = SmbConfig(
            smb_host=secrets["smb_host"],
            smb_username=secrets["smb_username"],
            smb_password=secrets["smb_password"],
            directory_path=secrets["directory_path"],
            share_name=secrets["share_name"],
            domain_name=secrets["domain_name"],
        )
        smb_reader = SmbManager(smb_config)
        return smb_reader

    def get_image(self, img_name):
        try:
            image_contents = self.get_file_content(img_name)
            open_cv_image = cv2.imdecode(np.frombuffer(image_contents, np.uint8), 1)
        except Exception as e:
            raise Exception(f"Error reading image from Samba!: {e}")

        if open_cv_image is None:
            raise FileNotFoundError(
                f"No image {img_name} found at {self.directory_path}"
            )

        image = Image.fromarray(cv2.cvtColor(open_cv_image, cv2.COLOR_BGR2RGB))
        return image

    def get_file(self, file_name, local_path):
        """
        Download a file from a Samba share to a local path.

        :param file_name: The name of the file to download.
        :param local_path: The local path (including file name) where the file will be saved.
        """
        try:
            # Ensure the local directory exists
            os.makedirs(os.path.dirname(local_path), exist_ok=True)

            remote_file_contents = self.get_file_content(file_name)

            # Open the local file and write the contents of the remote file into it
            with open(local_path, "wb") as local_file:
                local_file.write(remote_file_contents)

            logger.info(
                f"File {file_name} has been downloaded successfully to {local_path}."
            )
        except Exception as e:
            raise Exception(f"Error downloading file from Samba: {e}")

    def get_file_content(self, file_name):
        """
        Download a file from a Samba share and return its content as binary.

        :param file_name: The name of the file to download.
        :return: The binary content of the file.
        """
        try:
            # Open the remote file and read its contents into memory
            with smbclient.open_file(
                f"\\\\{self.smb_host}\\{self.share_name}\\{self.directory_path}\\{file_name}",
                username=self.smb_username,
                password=self.smb_password,
                mode="rb",
            ) as remote_file:
                file_content = remote_file.read()
            return file_content
        except Exception as e:
            raise Exception(f"Error downloading file from Samba: {e}")

    def check_connection(self):
        try:
            archive_path = (
                f"\\\\{self.smb_host}\\{self.share_name}\\{self.directory_path}"
            )
            return isdir(
                archive_path, username=self.smb_username, password=self.smb_password
            )
        except Exception:
            return False
