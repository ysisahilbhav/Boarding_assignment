from typing import Optional

from pydantic import BaseModel


class SmbConfig(BaseModel):
    smb_host: str
    smb_username: str
    smb_password: str
    directory_path: str
    share_name: str
    domain_name: Optional[str] = None


class S3Config(BaseModel):
    access_key: str
    secret_key: str
    bucket_name: str
    endpoint_url: Optional[str] = None
    verify: bool = False
