import boto3
import logging
import os
from botocore.exceptions import NoCredentialsError
from ysecret.SecretManager import SecretManager
from yloader.schemas import S3Config

logger = logging.getLogger(__name__)


class S3Manager:
    def __init__(self, s3Config: S3Config):
        self.access_key = s3Config.access_key
        self.secret_key = s3Config.secret_key
        self.bucket_name = s3Config.bucket_name
        self.endpoint_url = s3Config.endpoint_url
        self.s3 = boto3.client(
            "s3",
            aws_access_key_id=self.access_key,
            aws_secret_access_key=self.secret_key,
            endpoint_url=self.endpoint_url,
            verify=s3Config.verify,
        )

    @staticmethod
    def get_s3_perm(bucket_name, id=None) -> "S3Manager":
        if id is None:
            id = 138530
        secret_manger = SecretManager(use_password=True)
        secrets = secret_manger.get_secret_with_id(id)
        AWS_ACCESS_KEY_ID = secrets["AWS_ACCESS_KEY_ID"]
        AWS_SECRET_ACCESS_KEY = secrets["AWS_SECRET_ACCESS_KEY"]
        endpoint_url = secrets["AWS  ARN"]
        endpoint_url = "https://" + endpoint_url
        s3_config = S3Config(
            access_key=AWS_ACCESS_KEY_ID,
            secret_key=AWS_SECRET_ACCESS_KEY,
            bucket_name=bucket_name,
            endpoint_url=endpoint_url,
            verify=False,
        )
        return S3Manager(s3_config)

    @staticmethod
    def get_s3(bucket_name, id=None) -> "S3Manager":
        if id is None:
            id = 187178
        secret_manger = SecretManager(use_password=True)
        secrets = secret_manger.get_secret_with_id(id)
        AWS_ACCESS_KEY_ID = secrets["AWS_ACCESS_KEY_ID"]
        AWS_SECRET_ACCESS_KEY = secrets["AWS_SECRET_ACCESS_KEY"]
        s3_config = S3Config(
            access_key=AWS_ACCESS_KEY_ID,
            secret_key=AWS_SECRET_ACCESS_KEY,
            bucket_name=bucket_name,
            verify=False,
        )
        return S3Manager(s3_config)

    def upload_file(self, file_path, key):
        """Upload a file to an S3 bucket.

        :param file_path: File to upload
        :param key: S3 key (file path in bucket)
        """
        try:
            self.s3.upload_file(file_path, self.bucket_name, key)
            logger.info("File %s uploaded to %s.", file_path, key)
        except NoCredentialsError:
            logger.error("Credentials not available.")
            raise

    def download_file(self, key, file_path):
        """Download a file from an S3 bucket.

        :param key: S3 key (file path in bucket)
        :param file_path: File path for saving the downloaded file
        """
        try:
            self.s3.download_file(self.bucket_name, key, file_path)
            logger.info("File %s downloaded to %s.", key, file_path)
        except NoCredentialsError:
            logger.error("Credentials not available.")
            raise

    def upload_folder(self, folder_path, prefix=""):
        """Upload a folder to an S3 bucket.

        :param folder_path: Path to the folder to upload
        :param prefix: Prefix for S3 keys (folder path in bucket)
        """
        for root, dirs, files in os.walk(folder_path):
            for file in files:
                local_path = os.path.join(root, file)
                relative_path = os.path.relpath(local_path, folder_path)
                s3_key = os.path.join(prefix, relative_path).replace("\\", "/")

                self.upload_file(local_path, s3_key)

    def download_folder(self, prefix, local_path):
        """Download a folder from an S3 bucket.

        :param prefix: Prefix for S3 keys (folder path in bucket)
        :param local_path: Local path to store the downloaded folder
        """
        paginator = self.s3.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=self.bucket_name, Prefix=prefix):
            for obj in page.get("Contents", []):
                key = obj["Key"]
                dest_path = os.path.join(local_path, os.path.relpath(key, prefix))
                os.makedirs(os.path.dirname(dest_path), exist_ok=True)
                self.download_file(key, dest_path)

    def get_file_content(self, key):
        """
        Download a file from an S3 bucket and return its content as binary.

        :param key: S3 key (file path in bucket)
        :return: The binary content of the file.
        """
        try:
            response = self.s3.get_object(Bucket=self.bucket_name, Key=key)
            file_content = response["Body"].read()
            return file_content
        except NoCredentialsError:
            logger.error("Credentials not available.")
            return None
        except Exception as e:
            logger.error("Error downloading file from S3: %s", e)
            return None
