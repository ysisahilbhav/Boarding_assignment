# **What is it?**

Yardi data and model loader
* connecting to s3 (perm and non-perm) for loading data and model
* connecting to sbm file storage for downloading files
* have retry mechanism for downloading and uploading objects 

## **installation**

`pip install .`

Note: Use `-v` is for showing logs during installation 