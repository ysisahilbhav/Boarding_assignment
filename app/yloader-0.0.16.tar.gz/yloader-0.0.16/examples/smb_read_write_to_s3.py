import pandas as pd

from yloader.schemas import SmbConfig, S3Config
from yloader.smbManager import SmbManager
from yloader.s3Manager import S3Manager

smb_config = SmbConfig(
    smb_host="10.246.15.25",
    smb_username="100080001WEB",
    smb_password="",
    directory_path="CRM_Files",
    share_name="cifs02",
    domain_name="YCRMPC",
)
smb_reader = SmbManager(smb_config)


s3_config = S3Config(
    access_key="VT3KNHYULE7960PZX6F1",
    secret_key="",
    bucket_name="data",
    endpoint_url="https://s3.yardisgs.com:8082",
    verify=False,
)
s3Manager = S3Manager(s3_config)
s3Manager.download_file("yCRM/emails/data.xlsx", "data.xlsx")
df = pd.read_excel("data.xlsx")
number = 50
for index, row in df.iterrows():
    if int(index) > 50:
        break
    file_path = row["SFILENAME"]
    file_name = file_path.split("\\")[-1]
    local_dir = f"./downloaded/{file_name}"
    print("file_name", file_name)
    smb_reader.get_file(file_path, local_dir)
    s3Manager.upload_file(local_dir, f"yCRM/emails/{file_name}")
