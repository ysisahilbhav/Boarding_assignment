import os

from yloader.smbManager import SmbManager

os.environ["SECRET_AUTH_TOKEN"] = "pICt_VLCEH1N_"
smb_manager = SmbManager.get_samba_ycrm()

smb_manager.get_file(
    "OutlookEmails\\2024\\3\\8\\CRM_OUTLOOK_ATTACHMENT_03-08-2024 14-57-38-580_575281274.eml",
    "./test.eml",
)
