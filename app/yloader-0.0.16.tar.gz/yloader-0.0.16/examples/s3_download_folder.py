from yloader.s3Manager import S3Manager
from yloader.schemas import S3Config

s3_config = S3Config(
    access_key="AKIARKKZ4FWIZDMYCGPQ",
    secret_key="",
    bucket_name="mlai-invoice-ocr-models",
    endpoint_url=None,
    verify=False,
)
s3Manager = S3Manager(s3_config)
s3Manager.download_folder("test-images", "./test-images")
