import logging

from yloader.databases import (
    MsSQLClient,
    MsSQLCredentials,
    OracleSQLClient,
    OracleSQLCredentials,
)

logger = logging.getLogger(__name__)

mssql_client = MsSQLClient(
    MsSQLCredentials(
        username="sa",
        password="password123!",
        host="localhost",
        port=1433,
        db_name="msdb",
    ),
    # OR, from secrets server:
    # MsSQLCredentials.from_secret_server(secret_id=123),
    logger,
)

oracle_client = OracleSQLClient(
    OracleSQLCredentials(
        username="sa",
        password="password123!",
        host="localhost",
        port=1433,
        service_name="msdb",
    ),
    # OR, from secrets server:
    # OracleSQLCredentials.from_secret_server(secret_id=123),
    logger,
)

#
# In the examples below, mssql_client and oracle_client are interchangeable,
# they have the same interface
#

# Execute SQL with no return:
"""
mssql_client.execute("update ... set ... where id = ?", 100, retries=5, timeout=60)

await mssql_client.aexecute(
    "update ... set ... where id = ?", 100, retries=5, timeout=60
)

# Execute SQL with single row returned:

row = mssql_client.fetch_one(
    "select * from ... where id = ?", 100, retries=5, timeout=60
)

row = await mssql_client.afetch_one(
    "update ... set ... where id = ?", 100, retries=5, timeout=60
)


# Execute SQL with all rows returned:

row = mssql_client.fetch_all(
    "select * from ... where id = ?", 100, retries=5, timeout=60
)

row = await mssql_client.afetch_all(
    "update ... set ... where id = ?", 100, retries=5, timeout=60
)

# Execute SQL with df returned:

row = mssql_client.fetch_dataframe(
    "select * from ... where id = ?", 100, retries=5, timeout=60
)

row = await mssql_client.afetch_dataframe(
    "update ... set ... where id = ?", 100, retries=5, timeout=60
)
"""
