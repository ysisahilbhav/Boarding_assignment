import os

from yloader.s3Manager import S3Manager

os.environ["SECRET_AUTH_TOKEN"] = "A"
s3Manager = S3Manager.get_s3_perm("data")
file_content = s3Manager.get_file_content("k1-doc/test-6-Feb-2024/GT.xlsx")
print(file_content)
