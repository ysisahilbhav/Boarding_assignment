# **What is it?**

Yardi OCR is a package for applying OCR on invoices and other documents

It will help better cross team knowledge sharing and enable teams to use each other's
achievements.


## **installation**

### OCR

`pip install .[ocr-paddle] -v`

`pip install .[ocr-doctr] -v`

`pip install .[ocr-tesseract] -v`


Note: Use `-v` is for showing logs during installation 


