from yocr.OCRConfig import OCRConfig


class DoctrOCRConfig(OCRConfig):
    det_arch: str = "db_resnet50"
    reco_arch: str = "crnn_vgg16_bn"
    pretrained: bool = True
