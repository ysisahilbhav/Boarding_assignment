import logging
from typing import Union

from PIL import Image

from yocr.OCRConfig import OCRConfig
from yocr.OCRBase import OCRBase
from yocr.data_struct.Detection import Detection
from yocr.data_struct.DetectionBase import DetectionBase
from yocr.data_struct.OcrResult import OcrResult
from yocr.doctr.DoctrOCR import DoctrOCR
from yocr.trocr.TextRecognizer import TextRecognizer


class DocTR_TROCR(OCRBase):
    """
    Text detection is doctr
    Text recognition is TrOCR
    """

    def __init__(self, engineConfig: OCRConfig) -> None:
        super().__init__(engineConfig)
        self.text_detector = DoctrOCR(engineConfig)
        self.text_recognizer = TextRecognizer()

    # get image path or PIL image and return list of OcrResult
    def run(self, image: Union[str, Image.Image] = None, **kwargs) -> list[OcrResult]:
        if type(image) is str:
            logging.info("Start Detecting Texts")
            detections = self.text_detector.run_detection(image)
            logging.info("Start Recognizing Texts")
            return self.text_recognizer.run(detections, image=image)
        elif isinstance(image, Image.Image):
            logging.info("Start Detecting Texts")
            detections = self.text_detector.run_detection(image)
            logging.info("Start Recognizing Texts")
            ocr_results = self.text_recognizer.run(detections, image=image)
            return ocr_results
        else:
            raise Exception("image must be a string path or a PIL Image")

    def run_detection(self, image, **kwargs) -> list[DetectionBase]:
        if type(image) is str or isinstance(image, Image.Image):
            return self.text_detector.run_detection(image)
        else:
            raise Exception("image must be a string path or a PIL Image")

    def run_recognition(
        self, image, detections: list[Detection], **kwargs
    ) -> list[OcrResult]:
        ocr_results = self.text_recognizer.run(detections, image=image)
        print("got detection results")
        print(ocr_results)
        return ocr_results
