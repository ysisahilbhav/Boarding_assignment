import copy
import logging
import ssl
from typing import List, Union

import cv2
import torch
from PIL import Image
from tqdm import tqdm
from transformers import TrOCRProcessor, VisionEncoderDecoderModel

from yocr.data_struct.Detection import Detection
from yocr.data_struct.DetectionBase import DetectionBase
from yocr.data_struct.OcrResult import OcrResult
from yocr.data_struct.Recognition import Recognition

import numpy as np
from yocr.utils.CropUtils import get_crop_image
from yocr.utils.InferenceUtils import InferenceUtils

logger = logging.getLogger(__name__)


class TextRecognizer:
    def __init__(self) -> None:
        super().__init__()
        # load trocr model from transformers
        self.processor = TrOCRProcessor.from_pretrained("microsoft/trocr-base-printed")
        self.model = VisionEncoderDecoderModel.from_pretrained(
            "microsoft/trocr-base-printed"
        )
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        self.batch_size = 32
        self.max_length = 64
        self.model.to(self.device)
        print(f"running trocr on {self.device}")

    def run(
        self, detections: [Detection], image: Union[str, Image.Image]
    ) -> list[OcrResult]:
        """
        get image path or PIL image and return list of OcrResult
        """

        if InferenceUtils.is_image(image):
            img_rgb = np.array(image)
            img = img_rgb[:, :, ::-1].copy()
        elif type(image) is str:
            img = cv2.imread(image)
        else:
            raise Exception("frame must be a string path to an image or a PIL image")

        ori_im = img.copy()
        height, width = img.shape[:2]
        dt_boxes = self.get_unormalize_coordinates(detections, height, width)
        box_scores = [detection.conf_score for detection in detections]
        # unnormalized list of coordinates
        dt_boxes_list = [detection.coordinates for detection in detections]
        logger.info("use text recognizer")
        image_crops = []
        for bno in range(len(dt_boxes)):
            image_crop = get_crop_image(ori_im, dt_boxes[bno])
            image_crops.append(copy.deepcopy(image_crop))

        pixel_values = self.processor(
            images=image_crops, return_tensors="pt"
        ).pixel_values
        pixel_values = pixel_values.to(self.device)

        pixel_values = pixel_values.split(self.batch_size)
        rec_res = []
        for i in tqdm(range(len(pixel_values))):
            generated_id_for_batch = self.model.generate(
                pixel_values[i], max_length=self.max_length
            )
            res = self.processor.batch_decode(
                generated_id_for_batch, skip_special_tokens=True
            )
            rec_res.extend(res)
            # break
        assert len(rec_res) == len(dt_boxes_list)
        logger.info("preparing ocr results...")
        results = []
        for detection, box_score, rec_result in zip(detections, box_scores, rec_res):
            recognition = Recognition(
                text=str(rec_result),
                conf_score=float(box_score),
            )

            ocrResult = OcrResult(detection=detection, recognition=recognition)

            results.append(ocrResult)
        return results

    def get_unormalize_coordinates(
        self, detections: List[DetectionBase], height, width
    ):
        dt_boxes = []
        for detection in detections:
            dt_boxes.append(detection.get_unormalize_coordinates(height, width))
        dt_boxes_np = np.array(dt_boxes).astype(np.float32)
        return dt_boxes_np
