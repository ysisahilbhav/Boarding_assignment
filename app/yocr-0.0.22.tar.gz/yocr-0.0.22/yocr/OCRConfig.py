from enum import Enum
from typing import Union

from pydantic import BaseModel


class OCRMethod(Enum):
    tesseract = 0
    paddle = 1
    doctr = 2
    doctr_dt_trocr_rec = 3


class InferenceType(Enum):
    FULL = 0
    TILE = 1

    def __repr__(self):
        return self.name


class OCRConfig(BaseModel):
    #: OCR method to use : paddle, doctr, tesseract
    METHOD: OCRMethod = OCRMethod.tesseract
    #: if paddle, this is the path to the config file or loaded dict;
    #: if doctr, it is not required
    CONFIG_PATH: Union[dict, str] = "."
    # inference type
    INFERENCE_TYPE: InferenceType = InferenceType.FULL
    TILE_ROW_COUNT: int = 2
    TILE_COL_COUNT: int = 2
    TILE_OVERLAP: int = 200
