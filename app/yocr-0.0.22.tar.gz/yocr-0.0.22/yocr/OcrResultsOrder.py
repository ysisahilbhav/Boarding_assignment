from typing import Union

import numpy as np
from PIL import Image

from yocr.data_struct.Block import Block
from yocr.data_struct.Detection import Detection
from yocr.data_struct.OcrResult import OcrResult
from yocr.utils.InferenceUtils import InferenceUtils


class OcrResultsOrder:
    @staticmethod
    def get_segments_based_on_visual_lines(
        image: Union[Image.Image, str], steps=2
    ) -> [Detection]:
        """
        Get segments based on lines
        :param image: image path or PIL image
        :return: list of detections
        """
        if not InferenceUtils.is_image(image):
            image = Image.open(image)

        image_cv = np.asarray(image)[:, :, 0]
        vertical = False
        height, width = image_cv.shape
        if height > width:
            vals = np.sum(image_cv, axis=1) / width
            vertical = True
        else:
            vals = np.sum(image_cv, axis=0) / height

        diff_vals = np.diff(vals)
        indices = np.where(diff_vals > 100)[0]
        indices = np.insert(indices, 0, 0)
        indices = np.insert(indices, len(indices), height if vertical else width)

        indices_ = []
        dist = 30
        # if distance two element is less than dist, then merge them
        for i in range(len(indices) - 1):
            if indices[i + 1] - indices[i] > dist:
                indices_.append(indices[i])
        indices_.append(indices[-1])
        indices = indices_
        detections = []
        if vertical:
            for i in range(len(indices) - 1):
                coords = [
                    (0, indices[i]),
                    (image.width, indices[i]),
                    (image.width, indices[i + 1]),
                    (0, indices[i + 1]),
                ]
                # normalize coordinates
                coords = Detection.normalize_coords(coords, image.height, image.width)
                detections.append(Detection(coordinates=coords))
        else:
            for i in range(len(indices) - 1):
                # normalize coordinates
                coords = [
                    (indices[i], 0),
                    (indices[i + 1], 0),
                    (indices[i + 1], image.height),
                    (indices[i], image.height),
                ]
                coords = Detection.normalize_coords(coords, image.height, image.width)
                detections.append(Detection(coordinates=coords))

        last_dir_was_vertical = vertical
        for i in range(steps - 1):
            detections_ = []
            for detection in detections:
                detection: Detection
                detections_details = (
                    OcrResultsOrder.segment_in_next_direction_of_visual_lines(
                        image, detection, last_dir_was_vertical=last_dir_was_vertical
                    )
                )

                if len(detections_details) == 0:
                    detections_.append(detection)
                detections_.extend(detections_details)
            detections = detections_
            last_dir_was_vertical = not last_dir_was_vertical
        return detections

    @staticmethod
    def cluster_ocr_result_in_segments(
        ocrResults: [OcrResult], segments: [Detection]
    ) -> [[OcrResult]]:
        """
        Cluster ocr results in segments
        :param ocrResults: list of ocr results
        :param segments: list of segments
        :return: list of ocr results in segments
        """
        ocrResults_segmented = [[] for _ in range(len(segments))]
        for ocrResult in ocrResults:
            for seg_ind, segment in enumerate(segments):
                segment: Detection
                if segment.is_overlap(ocrResult.detection):
                    ocrResults_segmented[seg_ind].append(ocrResult)
                    break

        return ocrResults_segmented

    @staticmethod
    def segment_in_next_direction_of_visual_lines(
        image: Union[Image.Image, str], segment: Detection, last_dir_was_vertical=False
    ):
        if not InferenceUtils.is_image(image):
            image = Image.open(image)
        xyxy_unorm = segment.unormalize_xyxy(
            segment.get_coordinates_in_bbox(), image.height, image.width
        )
        crop_img = image.crop(xyxy_unorm)

        crop_img_cv = np.asarray(crop_img)[:, :, 0]
        height, width = crop_img_cv.shape
        vertical = last_dir_was_vertical
        # if vertical is True, we want to process in horizontal direction now
        if vertical:
            vals = np.sum(crop_img_cv, axis=0) / crop_img_cv.shape[0]
        else:
            vals = np.sum(crop_img_cv, axis=1) / crop_img_cv.shape[1]

        diff_vals = np.diff(vals)
        indices = np.where(diff_vals > 100)[0]
        indices = np.insert(indices, 0, 0)
        indices = np.insert(indices, len(indices), width if vertical else height)
        indices_ = []
        dist = 10
        # if distance two element is less than dist, then merge them
        for i in range(len(indices) - 1):
            if indices[i + 1] - indices[i] > dist:
                indices_.append(indices[i])
        indices_.append(indices[-1])
        indices = indices_
        detections = []
        if not vertical:
            for i in range(len(indices) - 1):
                coords = [
                    (0, indices[i]),
                    (crop_img.width, indices[i]),
                    (crop_img.width, indices[i + 1]),
                    (0, indices[i + 1]),
                ]
                # normalize coordinates
                coords = Detection.normalize_coords(
                    coords, crop_img.height, crop_img.width
                )
                detection = Detection(coordinates=coords)
                xyxy_unnormalized = detection.convert_relative_to_absolute_xyxy(
                    detection.get_coordinates_in_bbox_unnormalized(
                        crop_img.height, crop_img.width
                    ),
                    segment.get_coordinates_in_bbox_unnormalized(
                        image.height, image.width
                    ),
                )
                xyxy_normalized = detection.normalize_xyxy(
                    xyxy_unnormalized, image.height, image.width
                )
                detection.set_coordinates_from_bbox(xyxy_normalized)
                detections.append(detection)
        else:
            for i in range(len(indices) - 1):
                # normalize coordinates
                coords = [
                    (indices[i], 0),
                    (indices[i + 1], 0),
                    (indices[i + 1], crop_img.height),
                    (indices[i], crop_img.height),
                ]
                coords = Detection.normalize_coords(
                    coords, crop_img.height, crop_img.width
                )
                detection = Detection(coordinates=coords)
                xyxy_unnormalized = detection.convert_relative_to_absolute_xyxy(
                    detection.get_coordinates_in_bbox_unnormalized(
                        crop_img.height, crop_img.width
                    ),
                    segment.get_coordinates_in_bbox_unnormalized(
                        image.height, image.width
                    ),
                )
                xyxy_normalized = detection.normalize_xyxy(
                    xyxy_unnormalized, image.height, image.width
                )
                detection.set_coordinates_from_bbox(xyxy_normalized)

                detections.append(detection)

        return detections

    @staticmethod
    def order_clusters(ocrResults: [OcrResult]) -> [OcrResult]:
        """
        Order clusters of ocr results
        Args:
            ocrResults:

        """
        from sklearn.cluster import DBSCAN

        centers = []
        xyxys = []
        word_ids_pred = list(range(len(ocrResults)))
        angle = 0
        angle_conf_max = 0
        average_w = 0.0
        average_h = 0.0
        for ocrResult in ocrResults:
            xyxy = ocrResult.detection.get_coordinates_in_bbox()
            xyxys.append(xyxy)
            centers.append(
                (
                    (xyxy[0] + xyxy[2]) / 2,
                    (xyxy[1] + xyxy[3]) / 2,
                )
            )
            angle_conf = ocrResult.direction.conf_score
            if angle_conf >= angle_conf_max:
                angle_conf_max = angle_conf
                angle = ocrResult.direction.angle
            average_w += xyxy[2] - xyxy[0]
            average_h += xyxy[3] - xyxy[1]
        average_w = average_w / len(ocrResults)
        average_h = average_h / len(ocrResults)

        # Create a numpy array of 2D points
        points = np.array(centers)

        # Define a function to calculate the vertical distance between two points
        def vertical_distance(p1, p2):
            return abs(p1[0] - p2[0])

        def horizontal_distance(p1, p2):
            return abs(p1[1] - p2[1])

        # Set the epsilon and minimum_samples parameters for DBSCAN
        if angle == 90.0 or angle == 270.0:
            epsilon = 2 * average_w
            minimum_samples = 1
            try:
                # Create an instance of the DBSCAN class and fit it to the data
                dbscan = DBSCAN(
                    eps=epsilon,
                    min_samples=minimum_samples,
                    metric=vertical_distance,
                )
                dbscan.fit(points)

                # Get the cluster labels for each point
                labels = dbscan.labels_
                clusters = {}
                for i, label_ in enumerate(labels):
                    if label_ not in clusters:
                        clusters[label_] = []
                    clusters[label_].append(word_ids_pred[i])

                # order in each cluster based on bottom to top
                for k, v in clusters.items():
                    clusters[k] = sorted(v, key=lambda x: xyxys[x][3], reverse=True)
                # sort clusters based on left to right
                clusters = sorted(clusters.values(), key=lambda x: xyxys[x[0]][0])
                # print(clusters)

                word_ids_pred = [wi for cluster in clusters for wi in cluster]
                # print(clusters)
            except Exception as e:
                print(e)
                pass
            # print(word_ids_pred)

        else:
            # horizontal
            epsilon = 2 * average_h
            minimum_samples = 1
            try:
                dbscan = DBSCAN(
                    eps=epsilon,
                    min_samples=minimum_samples,
                    metric=horizontal_distance,
                )
                dbscan.fit(points)

                # Get the cluster labels for each point
                labels = dbscan.labels_

                clusters = {}
                for i, label_ in enumerate(labels):
                    if label_ not in clusters:
                        clusters[label_] = []
                    clusters[label_].append(word_ids_pred[i])

                # order in each cluster based on left to right
                for k, v in clusters.items():
                    clusters[k] = sorted(v, key=lambda x: xyxys[x][2])

                # sort clusters based on top to bottom
                clusters = sorted(clusters.values(), key=lambda x: xyxys[x[0]][1])

                word_ids_pred = [wi for cluster in clusters for wi in cluster]

                # print(clusters)
            except Exception as e:
                print(e)
            # print(word_ids_pred)
        # order ocr results
        ocrResults = sorted(
            ocrResults, key=lambda ocrResult: word_ids_pred[ocrResults.index(ocrResult)]
        )
        return ocrResults

    @staticmethod
    def order_inside_cluster_DBScan(ocrResults: [OcrResult]):
        from sklearn.cluster import DBSCAN

        centers = []
        for ocrResult in ocrResults:
            xyxy = ocrResult.detection.get_coordinates_in_bbox()
            centers.append(
                (
                    (xyxy[0] + xyxy[2]) / 2,
                    (xyxy[1] + xyxy[3]) / 2,
                    ocrResult.direction.angle,
                    ocrResult.direction.conf_score,
                )
            )

        def city_block_dist(p1, p2):
            if p1[2] != p2[2]:
                return 1

            return abs(p1[0] - p2[0]) ** 2 + abs(p1[1] - p2[1]) ** 2

        epsilon = 0.01
        minimum_samples = 1
        dbscan = DBSCAN(
            eps=epsilon,
            min_samples=minimum_samples,
            metric=city_block_dist,
        )
        dbscan.fit(centers)
        labels = dbscan.labels_

        ocrResults = sorted(
            ocrResults, key=lambda ocrResult: labels[ocrResults.index(ocrResult)]
        )
        labels = sorted(labels)

        ocr_clusters = {}
        for result, label in zip(ocrResults, labels):
            if label not in ocr_clusters:
                ocr_clusters[label] = []

            ocr_clusters[label].append(result)

        new_ordred_ocr_result = []
        xyxys_first_element = []
        for _, cluster_res in ocr_clusters.items():
            ordered_cluster_ocr = OcrResultsOrder.order_clusters(cluster_res)
            xyxys_first_element.append(
                ordered_cluster_ocr[0].detection.get_coordinates_in_bbox()
            )
            new_ordred_ocr_result.append(ordered_cluster_ocr)

        xyxys_first_element = np.asarray(xyxys_first_element)
        # left to right, top to bottom
        sorted_indices = np.lexsort(
            (xyxys_first_element[:, 1], xyxys_first_element[:, 0])
        )
        new_ordred_ocr_result = np.asarray(new_ordred_ocr_result)
        new_ordred_ocr_result = new_ordred_ocr_result[sorted_indices]
        new_ordred_ocr_result_flat = [
            item for sublist in new_ordred_ocr_result for item in sublist
        ]
        return new_ordred_ocr_result_flat

    @staticmethod
    def get_angle_of_segment(ocrResults: [OcrResult]) -> float:
        # get mod of direction as representative direction
        directions = [ocrResult.direction for ocrResult in ocrResults]
        directions = [direction for direction in directions if direction is not None]
        if len(directions) == 0:
            return 0
        angles = [direction.angle for direction in directions]
        # get the most representative angle
        angle = max(set(angles), key=angles.count)
        # get the most representative angle's confidence score
        return angle

    @staticmethod
    def order_ocr_res_segment(ocrResults: [OcrResult], width, height) -> [OcrResult]:
        """
        Order ocr results in segment
        :param ocrResults: list of ocr results
        :param width: width of image
        :param height: height of image
        :return: list of ocr results in segment
        """
        angle = OcrResultsOrder.get_angle_of_segment(ocrResults)
        if angle == 90.0 or angle == 270.0:
            ocrResults = OcrResultsOrder.order_inside_cluster_DBScan(ocrResults)
        else:
            ocrResults = OcrResultsOrder.order_words(ocrResults, width, height)
        return ocrResults

    @staticmethod
    def order_from_l2r_t2b(ocrResults: [OcrResult]):
        ocrResults = sorted(
            ocrResults, key=lambda ocrResult: ocrResult.detection.coordinates[0][1]
        )
        ocrResults = sorted(
            ocrResults, key=lambda ocrResult: ocrResult.detection.coordinates[0][0]
        )
        return ocrResults

    @staticmethod
    def order_words(ocrResults: [OcrResult], image_width: int, image_height: int):
        blocks = Block.get_blocks_from_word_level(ocrResults, image_width, image_height)
        # order blocks from top to bottom
        blocks = sorted(
            blocks,
            key=lambda block: block.coordinates[0][1] / 2 + block.coordinates[2][1] / 2,
        )

        OcrResults_ordered = []
        for block in blocks:
            # block.lines = block.lines[::-1]
            for line in block.get_lines_in_order():
                # print(line.get_text())
                for word in line.words:
                    OcrResults_ordered.append(word)

        return OcrResults_ordered

    @staticmethod
    def order_info_box(ocrResults, image: Union[Image.Image, str]):
        if isinstance(image, str):
            image = Image.open(image)
        width, height = image.size

        segments = OcrResultsOrder.get_segments_based_on_visual_lines(image, steps=3)
        ocrResults = OcrResultsOrder.cluster_ocr_result_in_segments(
            ocrResults, segments
        )
        final_ocr_results = []
        for i_seg, res_seg in enumerate(ocrResults):
            res_seg = OcrResultsOrder.order_ocr_res_segment(res_seg, width, height)
            final_ocr_results.extend(res_seg)

        return final_ocr_results
