from fastapi import HTTPException
from pdf2image import convert_from_bytes


def convert_pdf_to_images(pdf_content: bytes):
    try:
        # Convert PDF to images using pdf2image
        images = convert_from_bytes(pdf_content, fmt="png")
        return images
    except Exception as e:
        raise HTTPException(
            status_code=500, detail=f"Error converting PDF to images: {str(e)}"
        )
