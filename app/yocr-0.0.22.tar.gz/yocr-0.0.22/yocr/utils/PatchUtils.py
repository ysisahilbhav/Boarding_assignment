import copy

import numpy as np

from yocr.data_struct.Detection import Detection
from yocr.data_struct.DetectionBase import DetectionBase


def reset_xywh_on_patch(bbox, w_start, h_start):
    bbox[0] = bbox[0] - w_start
    bbox[1] = bbox[1] - h_start
    return bbox


def reset_xyxy_to_original(
    bbox, w_start, h_start, img_height, img_width, h_patch, w_patch
):
    # bbox is xyxy and is normalized
    bbox[0] = float(int(bbox[0] * w_patch) + w_start) / img_width
    bbox[1] = float(int(bbox[1] * h_patch) + h_start) / img_height
    bbox[2] = float(int(bbox[2] * w_patch) + w_start) / img_width
    bbox[3] = float(int(bbox[3] * h_patch) + h_start) / img_height
    return bbox


def reset_coordinates_to_original(
    coordinates, w_start, h_start, img_height, img_width, h_patch, w_patch
):
    # reset coordinates [(x,y),(),()] to original image and normalize
    coordinates = np.asarray(coordinates).astype(float)
    coordinates[:, 0] = (coordinates[:, 0] * w_patch + w_start) / img_width
    coordinates[:, 1] = (coordinates[:, 1] * h_patch + h_start) / img_height
    # return in [(x,y),(),()] format
    coordinates = [tuple(x) for x in coordinates]
    return coordinates


def get_xyxy_for_full_size_from_labelmeText(
    info, patch_bboxes, h_patch, w_patch, width, height
):
    reconstruct_target = []
    for info_patch, patch_bbox in zip(info, patch_bboxes):
        w_start, h_start, w_end, h_end = patch_bbox
        ann_image = info_patch["annotations"]
        target_bbox_patch = [
            normalize_xyxy(convert_xywh_to_xyxy(ann["bbox"]), h_patch, w_patch)
            for ann in ann_image
        ]
        for bbox_patch in target_bbox_patch:
            bbox_xyxy = reset_xyxy_to_original(
                bbox_patch, w_start, h_start, height, width, h_patch, w_patch
            )
            reconstruct_target.append(bbox_xyxy)
    return reconstruct_target


def get_detections_for_full_size_from_detection(
    results: [[Detection]], patch_bboxes, width, height
) -> [Detection]:
    reconstruct_out = []
    detections_patch: [Detection]
    for patch_bbox, detections_patch in zip(patch_bboxes, results):
        w_start, h_start, w_end, h_end = patch_bbox
        h_patch = h_end - h_start
        w_patch = w_end - w_start
        for detection in detections_patch:
            xyxy = detection.get_coordinates_in_bbox()
            xyxy = reset_xyxy_to_original(
                xyxy, w_start, h_start, height, width, h_patch, w_patch
            )
            coordinates = Detection.convert_xyxy_to_coordinates(xyxy)
            detection_ = copy.deepcopy(detection)
            detection_.coordinates = coordinates
            reconstruct_out.append(detection_)
    # apply Non maximum suppression
    merged_detections = DetectionBase.merge_if_overlap(reconstruct_out)
    return merged_detections


def get_xyxy_for_full_size_from_detections(
    results: [[Detection]], patch_bboxes, h_patch, w_patch, width, height
):
    reconstruct_out = []
    for patch_bbox, detections_patch in zip(patch_bboxes, results):
        w_start, h_start, w_end, h_end = patch_bbox
        for result in detections_patch:
            bbox_xyxy_patch = convert_polygon_to_xyxy(
                np.asarray(result.coordinates).ravel()
            )
            bbox_xyxy = reset_xyxy_to_original(
                bbox_xyxy_patch, w_start, h_start, height, width, h_patch, w_patch
            )
            reconstruct_out.append(bbox_xyxy)

    return reconstruct_out


def get_xyxy_for_full_size_from_polygons(
    polygons, patch_bboxes, h_patch, w_patch, width, height
):
    #: outs: [polygons] related to text boxes
    reconstruct_out = []
    for patch_bbox, poly_patch in zip(patch_bboxes, polygons):
        w_start, h_start, w_end, h_end = patch_bbox
        for poly in poly_patch:
            bbox_xyxy_patch = convert_polygon_to_xyxy(poly.ravel())
            bbox_xyxy = reset_xyxy_to_original(
                bbox_xyxy_patch, w_start, h_start, height, width, h_patch, w_patch
            )
            reconstruct_out.append(bbox_xyxy)
    return reconstruct_out


def patch_annotation(annotations, w_start, h_start, w_end, h_end):
    """
    :param annotations: list of annotations
    include bbox (xywh) and segmentation (polygon)
    :param w_start: start width
    :param h_start: start height

    :param w_end: end width
    :param h_end: end height

    """

    new_annotations = []
    for anno in annotations:
        bbox = (
            reset_xywh_on_patch(anno["bbox"], w_start, h_start)
            if len(anno["segmentation"]) == 0
            else reset_xywh_on_patch(
                convert_polygon_to_xywh(anno["segmentation"][0]), w_start, h_start
            )
        )
        patch_width = w_end - w_start
        patch_height = h_end - h_start
        # bbox should be in the patch area, if ovelap with boarder cut it to be inside
        if bbox[0] < 0:
            bbox[2] = bbox[2] + bbox[0]
            bbox[0] = 0
        if bbox[1] < 0:
            bbox[3] = bbox[3] + bbox[1]
            bbox[1] = 0
        if bbox[0] + bbox[2] > patch_width:
            bbox[2] = patch_width - bbox[0]
        if bbox[1] + bbox[3] > patch_height:
            bbox[3] = patch_height - bbox[1]
        if bbox[2] < 0 or bbox[3] < 0:
            continue

        anno["bbox"] = bbox
        new_annotations.append(anno)
    return new_annotations


def patch_image(img, row, column, overlap):
    height, width = img.shape[0], img.shape[1]
    h = height // row
    w = width // column
    patches = []
    bboxes = []
    for i in range(row):
        for j in range(column):
            h_start = i * h
            h_end = (i + 1) * h
            w_start = j * w
            w_end = (j + 1) * w
            w_start = w_start - overlap
            h_start = h_start - overlap
            w_end = w_end + overlap
            h_end = h_end + overlap
            w_start = max(0, w_start)
            h_start = max(0, h_start)
            w_end = min(img.shape[1], w_end)
            h_end = min(img.shape[0], h_end)

            patch = img[h_start:h_end, w_start:w_end]
            bboxes.append([w_start, h_start, w_end, h_end])
            patches.append(patch)
    return patches, bboxes


def normalize_xyxy(bbox, img_height, img_width):
    # bbox: [x1, y1, x2, y2]
    return [
        bbox[0] / img_width,
        bbox[1] / img_height,
        bbox[2] / img_width,
        bbox[3] / img_height,
    ]


def convert_xyxy_to_xywh(bbox):
    # bbox: [x1, y1, x2, y2]
    return [bbox[0], bbox[1], bbox[2] - bbox[0], bbox[3] - bbox[1]]


def convert_xywh_to_xyxy(bbox):
    # bbox: [x1, y1, w, h]
    return [bbox[0], bbox[1], bbox[0] + bbox[2], bbox[1] + bbox[3]]


def convert_polygon_to_xyxy(polygon_points):
    # polygon_points: list of [x1 y1 x2 y2,...]
    x1 = min(polygon_points[0::2])
    y1 = min(polygon_points[1::2])
    x2 = max(polygon_points[0::2])
    y2 = max(polygon_points[1::2])
    return [x1, y1, x2, y2]


def convert_polygon_to_xywh(polygon_points):
    # polygon_points: list of [x1 y1 x2 y2,...]
    x1 = min(polygon_points[0::2])
    y1 = min(polygon_points[1::2])
    x2 = max(polygon_points[0::2])
    y2 = max(polygon_points[1::2])
    return [x1, y1, x2 - x1, y2 - y1]
