from typing import List
import cv2
import numpy as np
import os
from shapely.geometry import Polygon

from yocr.data_struct.OcrResult import OcrResult


class VisualizationUtils:
    @staticmethod
    def generate_block_line_word_bbox_overlay(
        image, blocks, draw_block=True, draw_line=True, draw_word=True
    ):
        """
        Generate block, line and word bounding boxes on image
        Parameters
        ----------
        image: PIL image
        blocks : list of block object in ocr data structure
        Returns
        -------
        image with block, line and word bounding boxes drawn on it

        """
        from PIL import ImageDraw, ImageFont
        from yocr.data_struct.Line import Line

        def unnormalize_bbox(image, geo):
            return [
                (float(int(x * image.width)), float(int(y * image.height)))
                for x, y in geo
            ]

        draw = ImageDraw.Draw(image)
        plotted_words = 0
        for block in blocks:
            line: Line
            for line in block.lines:
                if draw_word:
                    word: OcrResult
                    for word in line.words:
                        geo = unnormalize_bbox(
                            image, word.detection.get_coordinates_in_geometry()
                        )
                        draw.rectangle(geo, outline="red", width=2)
                        plotted_words += 1

                if draw_line:
                    geo = unnormalize_bbox(image, line.get_coordinates_in_geometry())
                    draw.rectangle(geo, outline="green", width=3)
            if draw_block:
                geo = unnormalize_bbox(image, block.get_coordinates_in_geometry())
                draw.rectangle(geo, outline="blue", width=5)
        # add legend and make it large font
        # set font size
        font_size = 20
        font = ImageFont.load_default()
        font.__setattr__("size", font_size)

        # draw text, half opacity
        draw.text((0, 0), "Block", fill="blue", font=font)
        draw.text((0, 20), "Line", fill="green")
        draw.text((0, 40), "Word", fill="red")
        print("Plotted words: ", plotted_words)
        return image

    @staticmethod
    def generate_bbox_text_ovelay(
        im, bbox, label="", color_ind=0, txt_color=(255, 255, 255)
    ):
        """
        Args:
            im:
            bbox: [x1, y1, x2, y2]
            label: str
            color_ind:  int
            txt_color:  (255, 255, 255)

        Returns:

        """
        colors = Colors()  # create instance for 'from utils.plots import color
        color = colors(color_ind, True)
        p1, p2 = (int(bbox[0]), int(bbox[1])), (int(bbox[2]), int(bbox[3]))
        lw = max(round(sum(im.shape) / 2 * 0.0001), 2)  # line width
        cv2.rectangle(im, p1, p2, color, thickness=lw, lineType=cv2.LINE_AA)
        if label:
            tf = max(lw - 1, 1)  # font thickness
            w, h = cv2.getTextSize(label, 0, fontScale=lw / 3, thickness=tf)[
                0
            ]  # text width, height
            outside = p1[1] - h - 3 >= 0  # label fits outside box
            p2 = p1[0] + w, p1[1] - h - 3 if outside else p1[1] + h + 3
            cv2.rectangle(im, p1, p2, color, -1, cv2.LINE_AA)  # filled
            cv2.putText(
                im,
                label,
                (p1[0], p1[1] - 2 if outside else p1[1] + h + 2),
                0,
                lw / 3,
                txt_color,
                thickness=tf,
                lineType=cv2.LINE_AA,
            )

        return im

    @staticmethod
    def generate_xyxy_overlay(
        img, bbox_list, color=(0, 255, 0), thickness=2, out_filepath=None, display=False
    ):
        #
        # bbox: [x1, y1, x2, y2], normalized
        #
        from matplotlib import pyplot as plt

        for bbox in bbox_list:
            x1 = int(bbox[0] * img.shape[1])
            y1 = int(bbox[1] * img.shape[0])
            x2 = int(bbox[2] * img.shape[1])
            y2 = int(bbox[3] * img.shape[0])
            cv2.rectangle(img, (x1, y1), (x2, y2), color, thickness)
        if out_filepath:
            cv2.imwrite(out_filepath, img)
        if display:
            plt.imshow(img)
        return img

    @staticmethod
    def save_groundtruth_and_prediction_visualization(
        groundtruth_path: str, prediction_path: str, output_path: str
    ):
        import matplotlib.pyplot as plt

        pd_img = cv2.imread(prediction_path)
        pd_height, pd_width, _ = pd_img.shape
        gt_img = cv2.resize(
            cv2.imread(groundtruth_path),
            (pd_width, pd_height),
            interpolation=cv2.INTER_AREA,
        )

        h, w, _ = gt_img.shape
        if h > w:
            fig, axs = plt.subplots(1, 2, figsize=(30, 120))
        else:
            fig, axs = plt.subplots(2, 1, figsize=(120, 30))

        axs[0].imshow(pd_img)
        axs[0].set_title(f"prediction: `{prediction_path}`")
        axs[1].imshow(gt_img)
        axs[1].set_title(f"groundtruth: `{groundtruth_path}`")

        fig_dir = os.path.dirname(output_path)
        if not os.path.exists(fig_dir):
            os.mkdir(fig_dir)

        plt.tight_layout()
        plt.savefig(output_path, bbox_inches="tight")
        plt.close()

    @staticmethod
    def _draw_recognition_text_box(
        image: np.ndarray,
        det_record: dict,
        box_text: str,
        rect_color: tuple,
        text_color: tuple,
        thickness: int,
        text_size=None,
    ):
        # pd_image, gt, pd, color, thickness
        cv2.rectangle(
            image,
            det_record["coords"][0],
            det_record["coords"][2],
            rect_color,
            thickness,
        )
        tl_small = (det_record["coords"][0][0] + 1, det_record["coords"][0][1] + 1)
        br_small = (det_record["coords"][2][0] - 1, det_record["coords"][2][1] - 1)

        # smaller filled rect for white rect to overlay text on
        cv2.rectangle(image, tl_small, br_small, (255, 255, 255), -1)

        # adjust text anchor location by scaling wrt box height
        # w some piecewise y value
        text_anchor_x = det_record["coords"][0][0]
        text_anchor_y = int(
            0.5 * (det_record["coords"][2][1] + det_record["coords"][0][1])
        )  # center y of bbox
        box_height = det_record["coords"][2][1] - det_record["coords"][0][1]

        # piecewise offset: offset is proportional to box_height
        def anchor_offset(h):
            if h > 22:
                return 9
            elif h > 16:
                return 6
            else:
                return 3

        text_anchor = (text_anchor_x, text_anchor_y + anchor_offset(box_height))
        # adjust font size by scaling wrt box height
        # some linear eqn works well
        if text_size:
            box_height = text_size
        font_scale = 0.04 * box_height - 0.25

        cv2.putText(
            image,
            text=box_text,
            org=text_anchor,
            fontFace=cv2.FONT_HERSHEY_SIMPLEX,
            fontScale=font_scale,
            color=text_color,
            thickness=thickness,
        )

        return image

    @staticmethod
    def create_box_records(ocr_results: List[OcrResult], height: int, width: int):
        recs = []
        for idx, ocr_result in enumerate(ocr_results):
            coords = [
                (int(det[0] * width), int(det[1] * height))
                for det in ocr_result.detection.coordinates
            ]
            recs.append(
                {
                    "idx": idx,
                    "coords": coords,
                    "text": ocr_result.recognition.text,
                    "angle": int(ocr_result.direction.angle),
                    "poly": Polygon(coords),
                }
            )
        return recs


class Colors:
    # Ultralytics color palette https://ultralytics.com/
    def __init__(self):
        # hex = matplotlib.colors.TABLEAU_COLORS.values()
        hex = (
            "FF3838",
            "FF9D97",
            "FF701F",
            "FFB21D",
            "CFD231",
            "48F90A",
            "92CC17",
            "3DDB86",
            "1A9334",
            "00D4BB",
            "2C99A8",
            "00C2FF",
            "344593",
            "6473FF",
            "0018EC",
            "8438FF",
            "520085",
            "CB38FF",
            "FF95C8",
            "FF37C7",
        )
        self.palette = [self.hex2rgb("#" + c) for c in hex]
        self.n = len(self.palette)

    def __call__(self, i, bgr=False):
        c = self.palette[int(i) % self.n]
        return (c[2], c[1], c[0]) if bgr else c

    @staticmethod
    def hex2rgb(h):  # rgb order (PIL)
        return tuple(int(h[1 + i : 1 + i + 2], 16) for i in (0, 2, 4))
