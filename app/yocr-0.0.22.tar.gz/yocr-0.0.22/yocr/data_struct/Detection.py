from typing import List, Any, Optional
from pydantic import BaseModel

from yocr.data_struct.DetectionBase import DetectionBase


class Detection(BaseModel, DetectionBase):
    """
    Word detection
    """

    #: normalized coordinates of box clockwise from top left
    #:  [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
    coordinates: Optional[List[Any]] = []  # don't make exact type definition
    conf_score: Optional[float] = 0.0
    #: label of the box
    label: Optional[str] = "WORD"

    def __hash__(self):
        return hash(" ".join(str(self.get_sorted_coords(self.coordinates))))

    def to_dict(self):
        output = {
            "coordinates": self.coordinates,
            "conf_score": self.conf_score,
            "label": self.label,
        }

        return output
