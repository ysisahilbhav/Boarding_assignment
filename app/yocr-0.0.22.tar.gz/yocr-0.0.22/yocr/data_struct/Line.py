from typing import List, Union, Tuple, Optional

import numpy as np
from PIL import Image
from pydantic import BaseModel

from yocr.data_struct.DetectionBase import DetectionBase
from yocr.data_struct.OcrResult import OcrResult
from yocr.data_struct.Orientation import Orientation
from yocr.utils.InferenceUtils import InferenceUtils


class Line(BaseModel, DetectionBase):
    """
    :param coordinates: normalized coordinates of box clockwise from top left
    :param words:
    each line is a list of words.

    a word is OcrResult object contains detection, recognition, direction, text_type
    Defined in yocr.data_struct.OcrResult
    """

    #: normalized coordinates of box clockwise from top left
    #: [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
    coordinates: Optional[List[Tuple[float, float]]] = []
    words: Optional[List[OcrResult]] = []

    # todo: add direction

    def get_direction(self) -> Orientation:
        return self.words[0].direction

    def get_text(self) -> str:
        txt = " ".join([word.recognition.text for word in self.words])
        return txt

    def get_median_confidence(self) -> (float, float):
        recog_conf = np.median([word.recognition.conf_score for word in self.words])
        det_conf = np.median([word.detection.conf_score for word in self.words])
        return float(det_conf), float(recog_conf)

    def get_line_direction(self) -> Orientation:
        return self.words[0].direction

    def set_coordinates_from_word_coordinates(self):
        xmin = min([word.detection.coordinates[0][0] for word in self.words])
        xmax = max([word.detection.coordinates[2][0] for word in self.words])
        ymin = min([word.detection.coordinates[0][1] for word in self.words])
        ymax = max([word.detection.coordinates[2][1] for word in self.words])
        self.coordinates = [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
        return self

    def to_dict_schema(self):
        return {
            "coordinates": self.get_coordinates_in_xy_dict(),
            "words": [word.to_dict_schema() for word in self.words],
        }

    def run_recognition(self, ocr, image: Union[str, Image.Image]) -> [OcrResult]:
        from yocr.data_struct.Detection import Detection
        from yocr.data_struct.Block import Block

        if not InferenceUtils.is_image(image):
            file_name = image
        image = Image.open(file_name)

        detections = [Detection(coordinates=self.coordinates)]
        ocrResults: [OcrResult] = ocr.run_recognition(image, detections)

        _, ocrResults = Block.get_blocks_from_line_level(
            ocrResults, image.width, image.height
        )
        return ocrResults

    def run_ocr(self, ocr, image: Union[str, Image.Image]) -> List[OcrResult]:
        """
        Run ocr on the line for image
        :param ocr: ocr object
        :param image: image path or PIL image
        """
        if not InferenceUtils.is_image(image):
            file_name = image
        image = Image.open(file_name)
        xyxy_unorm = self.unormalize_xyxy(
            self.get_coordinates_in_bbox(), image.height, image.width
        )
        croped_image = image.crop(xyxy_unorm)

        ocrResults = ocr.run(croped_image)
        # add offset to coordinates
        for ocrResult in ocrResults:
            xyxy_unnormalized = self.unormalize_xyxy(
                ocrResult.detection.get_coordinates_in_bbox(),
                croped_image.height,
                croped_image.width,
            )
        xyxy_unnormalized = self.convert_relative_to_absolute_xyxy(
            xyxy_unnormalized, xyxy_unorm
        )
        xyxy_normalized = self.normalize_xyxy(
            xyxy_unnormalized, image.height, image.width
        )
        ocrResult.detection.set_coordinates_from_bbox(xyxy_normalized)

        return ocrResults
