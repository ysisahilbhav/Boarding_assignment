"""
OCRResult data structure
"""
from enum import Enum
from typing import Optional, List

from pydantic import BaseModel

from yocr.data_struct.Detection import Detection
from yocr.data_struct.Orientation import Orientation
from yocr.data_struct.Recognition import Recognition


class TextType(Enum):
    INVOICE = 0
    UTILITY_BILL = 1
    OTHER = 2


class OcrResult(BaseModel):
    """
    OcrResult data structure
    :param detection: detection object
    :param recognition: recognition object
    :param direction: orientation object
    :param text_type: text type: invoice, utility_bill, other

    >>> from yocr.data_struct.OcrResult import OcrResult
    >>> from yocr.data_struct.Detection import Detection
    >>> from yocr.data_struct.Recognition import Recognition
    >>> from yocr.data_struct.Orientation import Orientation
    >>> from yocr.data_struct.OcrResult import TextType
    >>> ocrResult = OcrResult(
    ...     detection=Detection(conf_score=0.9),
    ...     recognition=Recognition(text="test"),
    ...     direction=Orientation(conf_score=0.9),
    ... )

    """

    detection: Optional[Detection] = Detection()
    recognition: Optional[Recognition] = Recognition()
    direction: Optional[Orientation] = Orientation()

    def __post_init__(self):
        # set font size (normalized)
        if self.direction and len(self.detection.coordinates) == 4:
            top, right, bottom, left = self.detection.coordinates
            bbox_orientation = self.direction.get_direction_in_str()
            if bbox_orientation == "Vertical":
                height = bottom[1] - top[1]
                self.recognition.font_sizes = [height]
            elif bbox_orientation == "Horizontal":
                width = right[0] - left[0]
                self.recognition.font_sizes = [width]
            else:
                raise Exception(
                    "Cannot infer fontsize, orientation direction "
                    "must be 'Vertical' or 'Horizontal'"
                )

    # to dictionary from data structure without any change.
    def to_dict_original(self):
        return self.prepare_output_remove_optionals(
            self.detection, self.recognition, self.direction
        )

    def from_dict_schema(self, data):
        self.detection = Detection(
            conf_score=data["detection"]["conf_score"],
        )
        self.detection.set_coordinates_from_xy(data["detection"]["coordinates"])

        self.recognition = Recognition(**data["recognition"])

        if "direction" in data:
            self.direction = Orientation(**data["direction"])
        return self

    @staticmethod
    def overlap_with_detection_iou_based(
        ocrResults: ["OcrResult"], detection: Detection, iou_threshold: float = 0.5
    ):
        """
        Check if the ocr result overlaps with the given xywh box
        :param ocrResults: list of ocr results
        :param detection: detection object
        :return: list of ocr results that overlap with the given detection
        """
        ocrResults_ = []
        for ocrResult in ocrResults:
            if ocrResult.detection.is_overlap_iou(detection, iou_threshold):
                ocrResults_.append(ocrResult)
        return ocrResults_

    @staticmethod
    def overlap_with_detections_iou_based(
        ocrResults: ["OcrResult"], detections: [Detection], iou_threshold: float = 0.5
    ):
        """
        Check if the ocr result overlaps with the given xywh box
        :param ocrResults: list of ocr results
        :param detection: detection object
        :return: list of ocr results that overlap with the given detections
        """
        ocrResults_ = []
        for det in detections:
            for ocrResult in ocrResults:
                if ocrResult.detection.is_overlap_iou(det, iou_threshold):
                    ocrResults_.append(ocrResult)
        return ocrResults_

    @staticmethod
    def overlap_with_detection(ocrResults: ["OcrResult"], detection: Detection):
        """
        Check if the ocr result overlaps with the given xywh box
        :param ocrResults: list of ocr results
        :param detection: detection object
        :return: list of ocr results that overlap with the given detection
        """
        ocrResults_ = []
        for ocrResult in ocrResults:
            if ocrResult.detection.is_overlap(detection):
                ocrResults_.append(ocrResult)
        return ocrResults_

    @staticmethod
    def overlap_with_detections(ocrResults: ["OcrResult"], detections: [Detection]):
        """
        Check if the ocr result overlaps with the given xywh box
        :param ocrResults: list of ocr results
        :param detection: detection object
        :return: list of ocr results that overlap with the given detections
        """
        ocrResults_ = []
        for det in detections:
            for ocrResult in ocrResults:
                if ocrResult.detection.is_overlap(det):
                    ocrResults_.append(ocrResult)
        return ocrResults_

    @staticmethod
    def prepare_output_remove_optionals(
        detection: Detection, recognition: Recognition, direction: Orientation
    ):
        if direction.conf_score == -1:
            return {
                "detection": detection.to_dict(),
                "recognition": recognition.to_dict(),
            }
        return {
            "detection": detection.to_dict(),
            "recognition": recognition.to_dict(),
            "direction": direction.__dict__,
        }

    @staticmethod
    def unique(ocrRes: ["OcrResult"]):
        """
        Remove duplicate ocr results if IoU is greater than 0.5,
         keep the one with higher confidence score for text recognition
        :param ocrRes: list of ocr results
        :return: list of unique ocr results
        """
        # if IoU of two detection is greater than 0.5,
        # remove the one with lower confidence
        # if IoU of two detection is less than 0.5, keep both
        unique_ocrRes = []
        for i in range(len(ocrRes)):
            for j in range(i + 1, len(ocrRes)):
                if ocrRes[i].detection.iou(ocrRes[j].detection) > 0.5:
                    if (
                        ocrRes[i].recognition.conf_score
                        >= ocrRes[j].recognition.conf_score
                    ):
                        ocrRes[j].detection.conf_score = -1
                        unique_ocrRes.append(ocrRes[i])
                    else:
                        ocrRes[i].detection.conf_score = -1
                        unique_ocrRes.append(ocrRes[j])
                    break
            else:
                unique_ocrRes.append(ocrRes[i])
        return unique_ocrRes

    def get_unnormalized_fontsize(
        self, image_height: float, image_width: float
    ) -> List[float]:
        assert self.direction
        bbox_orientation = self.direction.get_direction_in_str()
        if bbox_orientation == "Vertical":
            return [image_width * fs for fs in self.recognition.font_sizes]
        elif bbox_orientation == "Horizontal":
            return [image_height * fs for fs in self.recognition.font_sizes]
        else:
            raise Exception(
                "Cannot infer fontsize, orientation direction "
                "must be 'Vertical' or 'Horizontal'"
            )
