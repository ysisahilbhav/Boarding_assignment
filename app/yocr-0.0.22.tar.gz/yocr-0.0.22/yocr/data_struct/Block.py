import logging
from typing import List, Union, Optional, Tuple

import numpy as np
from PIL import Image
from pydantic import BaseModel

from yocr.utils.InferenceUtils import InferenceUtils

try:
    from doctr.models import builder
except ImportError:
    logging.warning("Doctr is not installed, please install it to use DoctrOCR")
    DocumentBuilder = None

from yocr.data_struct.Detection import Detection
from yocr.data_struct.DetectionBase import DetectionBase
from yocr.data_struct.Line import Line
from yocr.data_struct.OcrResult import OcrResult
from yocr.data_struct.Recognition import Recognition


class Block(BaseModel, DetectionBase):
    """
    Block is a group of lines

    :param coordinates: normalized coordinates of box clockwise from top left
    :param lines: list of lines

    """

    #: normalized coordinates of box clockwise from top left
    #:  [(xmin, ymin), (xmax, ymin), (xmax, ymax), (xmin, ymax)]
    coordinates: Optional[List[Tuple[float, float]]] = []
    lines: Optional[List[Line]] = []
    name: Optional[str] = None

    def get_text(self) -> [str]:
        text = []
        for line in self.get_lines_in_order():
            line: Line
            text.append(" ".join([word.recognition.text for word in line.words]))
        return text

    def to_dict_schema(self):
        return {
            "coordinates": self.get_coordinates_in_xy_dict(),
            "lines": [line.to_dict_schema() for line in self.lines],
        }

    def run_ocr(self, ocr, image: Union[str, Image.Image]) -> List[OcrResult]:
        """
        Run ocr on block for image
        :param ocr: ocr object
        :param image: image path or PIL image
        """
        if not InferenceUtils.is_image(image):
            file_name = image
            image = Image.open(file_name)
        xyxy_unorm = self.unormalize_xyxy(
            self.get_coordinates_in_bbox(), image.height, image.width
        )
        croped_image = image.crop(xyxy_unorm)

        ocrResults = ocr.run(croped_image)

        # add offset to coordinates
        for ocrResult in ocrResults:
            xyxy_unnormalized = self.unormalize_xyxy(
                ocrResult.detection.get_coordinates_in_bbox(),
                croped_image.height,
                croped_image.width,
            )
            xyxy_unnormalized = self.convert_relative_to_absolute_xyxy(
                xyxy_unnormalized, xyxy_unorm
            )
            xyxy_normalized = self.normalize_xyxy(
                xyxy_unnormalized, image.height, image.width
            )
            ocrResult.detection.set_coordinates_from_bbox(xyxy_normalized)
            # ocrResult.detection.coordinates =
        return ocrResults

    def get_lines_in_order(self) -> [Line]:
        """
        Get lines in order
        """
        lines = self.lines
        lines.sort(
            key=lambda line: line.coordinates[0][1] / 2 + line.coordinates[2][1] / 2
        )
        return lines

    @staticmethod
    def get_blocks_from_line_level(
        lines: [OcrResult], image_width, image_height, paragraph_break=0.035
    ):
        """
        convert line to word, then call get_blocks_from_word_level func to get blocks
        Note: words are not very accurate, but lines are trustable
        If you want to get more words(less accurate), you can use words_ocr_res
        """
        words_ocr_res: [OcrResult] = []
        line: OcrResult
        # split each line to word and separate their bbox based on their length
        for line in lines:
            # xyxy = line.detection.get_coordinates_in_bbox()
            conf_line_detection = line.detection.conf_score
            conf_line_recognition = line.recognition.conf_score
            line_strip = line.recognition.text  # .strip()
            len_line = len(line_strip)
            words = line_strip.split(" ")
            # if line is empty, skip
            if len(words) == 0 or len_line == 0:
                continue
            # split bbox to smaller bbox based on word length
            # get word bbox
            for word in words:
                # split [xmin, ymin, xmax, ymax] to multiple bbox
                if len(word) == 0:
                    continue
                words_ocr_res.append(
                    OcrResult(
                        detection=Detection(
                            coordinates=line.detection.coordinates,
                            conf_score=conf_line_detection,
                        ),
                        recognition=Recognition(
                            text=word, conf_score=conf_line_recognition
                        ),
                        direction=line.direction,
                    )
                )
        return (
            Block.get_blocks_from_word_level(
                words_ocr_res, image_width, image_height, paragraph_break
            ),
            words_ocr_res,
        )

    @staticmethod
    def get_blocks_from_word_level(
        ocrResults: [OcrResult], image_width, image_height, paragraph_break=0.035
    ) -> ["Block"]:
        # create dictionay for ocr results with key is coordinates of detection
        # and value is ocr result
        ocrResults_dict = {}
        bboxes = []
        for ocrResult in ocrResults:
            # create key
            new_hash = ocrResult.detection.__hash__()
            ocrResults_dict[new_hash] = ocrResult
            bboxes.append(ocrResult.detection.get_coordinates_in_bbox())

        bboxes = np.asarray(bboxes)  # N x 4

        pred_text = [
            (ocrResult.recognition.text, ocrResult.recognition.conf_score)
            for ocrResult in ocrResults
        ]
        documentBuilder = builder.DocumentBuilder(paragraph_break=paragraph_break)
        out = documentBuilder([bboxes], [pred_text], [(image_height, image_width)])

        # we suppose it is only one page
        page = out.pages[0]
        blocks = []
        for block in page.blocks:
            block_ = Block(
                coordinates=Block.convert_geometry_to_coordinate(block.geometry)
            )
            vertical_lines = []
            for line in block.lines:
                words_in_line = []
                for word in line.words:
                    wordCoord = Detection.convert_geometry_to_coordinate(word.geometry)
                    hash_key = hash(
                        " ".join(str(Detection.get_sorted_coords(wordCoord)))
                    )
                    word = ocrResults_dict[hash_key]
                    words_in_line.append(word)
                if not words_in_line:
                    continue
                if words_in_line[-1].direction.angle > 0.0:
                    # paddle does bottom up
                    words_in_line = words_in_line[::-1]
                    line_ = Line(words=words_in_line)
                    line_.set_coordinates_from_word_coordinates()
                    vertical_lines.append(line_)
                else:
                    line_ = Line(words=words_in_line)
                    line_.set_coordinates_from_word_coordinates()
                    block_.lines.append(line_)
            # reverse order of lines that are vertical
            vertical_lines = vertical_lines[::-1]
            block_.lines.extend(vertical_lines)
            blocks.append(block_)
        return blocks
