from typing import Optional, Literal

from pydantic import BaseModel
from yocr.data_struct.OcrResult import OcrResult


class MainServiceConfig(BaseModel):
    page_to_process: Optional[int] = 0
    file_type: Optional[Literal["image", "pdf"]] = "image"
    ocr_level: Optional[Literal["word", "line"]] = "word"
    ocr_engine: Optional[Literal["tesseract", "doctr", "doctr_trocr"]] = "tesseract"
    inference_type: Optional[Literal["TILE", "FULL"]] = "FULL"
    tile_row_count: Optional[int] = 3
    tile_col_count: Optional[int] = 3
    tile_overlap: Optional[int] = 300


class MainServiceResponse(BaseModel):
    results: list[OcrResult]
    processing_time: float
