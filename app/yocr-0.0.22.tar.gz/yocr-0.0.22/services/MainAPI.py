import io
import logging
import os
import time
from typing import Annotated

import numpy as np
from PIL import Image
from fastapi import FastAPI, UploadFile, File, Depends, Response, HTTPException

from services.schemas import MainServiceResponse, MainServiceConfig
from yocr.OCR import OCR
from yocr.OCRConfig import OCRConfig, OCRMethod, InferenceType
from yocr.data_struct.OcrResult import OcrResult
from yocr.pdf2png.compression import zip_images
from yocr.pdf2png.conversion import convert_pdf_to_images

app = FastAPI()

logger = logging.getLogger(__name__)


@app.on_event("startup")
async def startup_event():
    # to download at startup time
    if os.getenv("GPU", False) is True:
        from yocr.trocr.DocTR_TROCR_inference import DocTR_TROCR

        DocTR_TROCR(OCRConfig(METHOD=OCRMethod.doctr_dt_trocr_rec))


async def get_ocr_config(config: MainServiceConfig) -> OCRConfig:
    ocrConfig = OCRConfig()
    if config.ocr_engine == "tesseract":
        ocrConfig.METHOD = OCRMethod.tesseract
    elif config.ocr_engine == "doctr":
        ocrConfig.METHOD = OCRMethod.doctr
    elif config.ocr_engine == "doctr_trocr":
        ocrConfig.METHOD = OCRMethod.doctr_dt_trocr_rec
    else:
        ocrConfig.METHOD = OCRMethod.paddle

    ocrConfig.INFERENCE_TYPE = (
        InferenceType.FULL if config.inference_type == "FULL" else InferenceType.TILE
    )
    ocrConfig.TILE_COL_COUNT = config.tile_col_count
    ocrConfig.TILE_ROW_COUNT = config.tile_row_count
    return ocrConfig


@app.post("/process")
async def process_request(
    image: Annotated[UploadFile, File(description="A file read as UploadFile")],
    config: MainServiceConfig = Depends(),
) -> MainServiceResponse:
    file_content = await image.read()
    if config.file_type == "image":
        # Convert the file content to a Pillow image
        image_pil = Image.open(io.BytesIO(file_content)).convert("RGB")
        logger.info("Image is loaded")
    else:
        logger.info("Converting pdf to image")
        images = convert_pdf_to_images(file_content)
        if config.page_to_process >= len(images):
            raise HTTPException(
                500, "page_to_process is set more than number of available page in pdf!"
            )
        image_pil = images[config.page_to_process]

    ocrConfig: OCRConfig = await get_ocr_config(config)
    logger.info(f"OCR Config: {ocrConfig}")
    ocr = OCR(ocrConfig)
    logger.info(f"Running {ocrConfig.METHOD} OCR...")
    start = time.time()
    ocrResults: list[OcrResult] = ocr(image_pil)
    processing_time = time.time() - start
    return MainServiceResponse(results=ocrResults, processing_time=processing_time)


@app.post("/pdf2png")
async def pdf2png(
    pdf: Annotated[UploadFile, File(description="A file read as UploadFile")]
) -> Response:
    pdf_content = await pdf.read()
    # Convert the file content to a Pillow image
    images = convert_pdf_to_images(pdf_content)
    print(f"converted to {len(images)} images...")
    # Create a ZIP archive
    zip_buffer = zip_images(images)

    # Set the response headers for automatic download
    response = Response(content=zip_buffer.getvalue(), media_type="application/zip")
    response.headers["Content-Disposition"] = f"attachment; filename=images.zip"
    return response


@app.post("/visualize_ocr")
async def visualize_ocr(
    image: Annotated[UploadFile, File(description="A file read as UploadFile")],
    config: MainServiceConfig = Depends(),
) -> Response:
    import cv2

    file_content = await image.read()
    if config.file_type == "image":
        # Convert the file content to a Pillow image
        image_pil = Image.open(io.BytesIO(file_content)).convert("RGB")
        logger.info("Image is loaded")
    else:
        logger.info("Converting pdf to image")
        images = convert_pdf_to_images(file_content)
        if config.page_to_process >= len(images):
            raise HTTPException(
                500, "page_to_process is set more than number of available page in pdf!"
            )
        image_pil = images[config.page_to_process]

    ocrConfig: OCRConfig = await get_ocr_config(config)
    logger.info(f"OCR Config: {ocrConfig}")
    ocr = OCR(ocrConfig)
    logger.info(f"Running {ocrConfig.METHOD} OCR...")
    ocrResults: list[OcrResult] = ocr(image_pil)
    image_np = ocr.visualize_ocr_results(image_pil, ocrResults)
    side_by_side_image_np = np.concatenate((np.asarray(image_pil), image_np), axis=1)
    # Convert the OpenCV image to bytes
    _, result_image_content = cv2.imencode(".png", side_by_side_image_np)
    result_image_content = result_image_content.tobytes()
    response = Response(content=result_image_content, media_type="image/png")
    response.headers[
        "Content-Disposition"
    ] = "attachment; filename=visualized_ocr_result.png"
    return response
