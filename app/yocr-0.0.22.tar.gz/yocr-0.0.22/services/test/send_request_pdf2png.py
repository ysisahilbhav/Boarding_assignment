import requests
import json
from yocr.pdf2png.compression import unzip_content_to_images

# Replace the following variables with your actual values
base_url = "http://localhost:8001"  # Replace with your FastAPI server URL
endpoint = "/pdf2png"  # Replace with your actual endpoint
pdf_file_path = "/home/antecessor/projects/Data/k1doc/Bob Hope/BH_Center_C_Entity.pdf"  # Replace with the path to your image file

# Prepare the image file and configuration data
with open(pdf_file_path, "rb") as pdf_file:
    files = {"pdf": pdf_file}

    # Send a POST request to the FastAPI endpoint using requests
    response = requests.post(base_url + endpoint, files=files)

    # Print the response from the server
    print(response.status_code)
    if response.status_code == 200:
        images = unzip_content_to_images(response.content)
        print(f"number of pages: {len(images)}")
