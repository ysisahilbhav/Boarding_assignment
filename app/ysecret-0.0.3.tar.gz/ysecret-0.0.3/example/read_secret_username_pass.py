import os

from ysecret.SecretManager import SecretManager

os.environ["SECRET_USERNAME"] = "mlai_api_dev"
os.environ["SECRET_PASSWORD"] = "itD*2!$X5sn9R5XQtPd"

secret_manager = SecretManager(use_password=True)


sec = secret_manager.get_secret_with_id(id_=163488)
print(sec)
