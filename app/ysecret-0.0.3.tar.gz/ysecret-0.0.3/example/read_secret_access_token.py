import os
from pprint import pprint

from ysecret.SecretManager import SecretManager

os.environ["SECRET_AUTH_TOKEN"] = "AgI_###"
secret_manager = SecretManager()

secret = secret_manager.get_secret_with_id(180550)
pprint(secret)