# **What is it?**

Yardi secret manager

## **installation**

`pip install .`

Note: Use `-v` is for showing logs during installation 