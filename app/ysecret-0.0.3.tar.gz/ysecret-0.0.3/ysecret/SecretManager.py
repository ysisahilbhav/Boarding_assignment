import os

from delinea.secrets.server import AccessTokenAuthorizer, SecretServer, PasswordGrantAuthorizer


class SecretManager:
    def __init__(self, use_password = True):
        super().__init__()
        self.url = "https://secretserver.yardisec.com/"
        if use_password:
            user_name = os.getenv("SECRET_USERNAME")
            password = os.getenv("SECRET_PASSWORD")
            authorizer = PasswordGrantAuthorizer(self.url,user_name, password)
        else:
            access_token = os.getenv("SECRET_AUTH_TOKEN")
            authorizer = AccessTokenAuthorizer(access_token)

        self.secret_server = SecretServer(self.url, authorizer)

    def get_secret_with_id(self, id_: int) -> dict:
        secret = self.secret_server.get_secret(id_)
        secrets_ = {}
        for item in secret["items"]:
            secrets_[item["fieldName"]] = item["itemValue"]
        return secrets_
